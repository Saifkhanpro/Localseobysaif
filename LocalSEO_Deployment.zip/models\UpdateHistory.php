<?php
namespace Models;
use Core\Model;

class UpdateHistory extends Model {
    protected $table = 'update_history';
    protected $fillable = ['from_version', 'to_version', 'update_type', 'status', 'completed_at', 'updated_by', 'ip_address'];
}
