<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-menu-button-wide me-2 text-primary"></i> <?= $pageTitle ?></h2>
</div>

<div class="row g-4">
    <!-- Left Col: Available Items -->
    <div class="col-md-4">
        <div class="accordion shadow-sm" id="menuItemsAccordion">
            <!-- Pages -->
            <div class="accordion-item border-0 border-bottom">
                <h2 class="accordion-header">
                    <button class="accordion-button bg-white fw-bold text-dark" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePages">
                        CMS Pages
                    </button>
                </h2>
                <div id="collapsePages" class="accordion-collapse collapse show" data-bs-parent="#menuItemsAccordion">
                    <div class="accordion-body bg-light p-3">
                        <div class="menu-item-list border p-2 bg-white rounded" style="max-height: 200px; overflow-y: auto;">
                            <?php foreach($pages as $p): ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input page-chk" type="checkbox" value="<?= $p['id'] ?>" data-title="<?= htmlspecialchars($p['title']) ?>" data-url="/<?= htmlspecialchars($p['slug']) ?>" id="page_<?= $p['id'] ?>">
                                    <label class="form-check-label small" for="page_<?= $p['id'] ?>">
                                        <?= htmlspecialchars($p['title']) ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="text-end mt-2">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="addSelectedToMenu('page-chk')">Add to Menu</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Categories -->
            <div class="accordion-item border-0 border-bottom">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed bg-white fw-bold text-dark" type="button" data-bs-toggle="collapse" data-bs-target="#collapseCats">
                        Blog Categories
                    </button>
                </h2>
                <div id="collapseCats" class="accordion-collapse collapse" data-bs-parent="#menuItemsAccordion">
                    <div class="accordion-body bg-light p-3">
                        <div class="menu-item-list border p-2 bg-white rounded" style="max-height: 200px; overflow-y: auto;">
                            <?php foreach($categories as $c): ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input cat-chk" type="checkbox" value="<?= $c['id'] ?>" data-title="<?= htmlspecialchars($c['name']) ?>" data-url="/category/<?= htmlspecialchars($c['slug']) ?>" id="cat_<?= $c['id'] ?>">
                                    <label class="form-check-label small" for="cat_<?= $c['id'] ?>">
                                        <?= htmlspecialchars($c['name']) ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="text-end mt-2">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="addSelectedToMenu('cat-chk')">Add to Menu</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Custom Links -->
            <div class="accordion-item border-0">
                <h2 class="accordion-header">
                    <button class="accordion-button collapsed bg-white fw-bold text-dark" type="button" data-bs-toggle="collapse" data-bs-target="#collapseCustom">
                        Custom Links
                    </button>
                </h2>
                <div id="collapseCustom" class="accordion-collapse collapse" data-bs-parent="#menuItemsAccordion">
                    <div class="accordion-body bg-light p-3">
                        <div class="mb-2">
                            <label class="small text-muted fw-bold">URL</label>
                            <input type="url" id="customUrl" class="form-control form-control-sm" value="https://">
                        </div>
                        <div class="mb-3">
                            <label class="small text-muted fw-bold">Link Text</label>
                            <input type="text" id="customText" class="form-control form-control-sm">
                        </div>
                        <div class="text-end">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="addCustomToMenu()">Add to Menu</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Col: Menu Editor -->
    <div class="col-md-8">
        <form method="POST" action="/admin/menus/save" id="menuForm">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center gap-3">
                        <span class="fw-bold">Select Menu to Edit:</span>
                        <select name="menu_type" id="menuTypeSelect" class="form-select w-auto" onchange="switchMenu(this.value)">
                            <option value="primary" <?= ($_GET['menu'] ?? 'primary') === 'primary' ? 'selected' : '' ?>>Primary Navigation (Header)</option>
                            <option value="footer" <?= ($_GET['menu'] ?? '') === 'footer' ? 'selected' : '' ?>>Footer Links</option>
                        </select>
                    </div>
                    <button type="button" class="btn btn-primary shadow-sm px-4 fw-bold" onclick="saveMenu()">Save Menu</button>
                </div>
                
                <div class="card-body bg-light" style="min-height: 400px;">
                    <input type="hidden" name="menu_data" id="menuDataOutput">
                    
                    <div class="alert alert-info py-2 small mb-4">
                        <i class="bi bi-info-circle me-1"></i> Drag and drop items to reorder them. Click the arrow on the right to edit details or remove an item. 
                        <strong>Note: Sub-menus (nested trees) can be implemented by dragging items slightly to the right in a full JS implementation setup.</strong>
                    </div>

                    <!-- Menu List Container (Using simple JS implementation for MVP) -->
                    <ul id="menuList" class="list-unstyled mb-0" style="max-width: 500px;">
                        <!-- JS injected here -->
                    </ul>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
<script>
// Mock Menu Data Injection
const menus = <?= json_encode($menus) ?>;
let currentMenu = '<?= rtrim(htmlspecialchars($_GET['menu'] ?? 'primary')) ?>';
if(!menus[currentMenu]) currentMenu = 'primary';
let activeData = menus[currentMenu] || [];

function renderMenu() {
    const list = document.getElementById('menuList');
    list.innerHTML = '';
    
    activeData.forEach((item, index) => {
        const li = document.createElement('li');
        li.className = 'card mb-2 border shadow-sm menu-node';
        li.dataset.id = item.id || Date.now() + index;
        li.dataset.title = item.title;
        li.dataset.url = item.url;
        
        li.innerHTML = `
            <div class="card-body p-3 d-flex justify-content-between align-items-center cursor-move" style="cursor: grab;">
                <div class="fw-bold">
                    <i class="bi bi-grip-vertical text-muted me-2"></i> 
                    <span class="item-title">${item.title}</span> 
                    <small class="text-muted fw-normal ms-2">(${item.url})</small>
                </div>
                <button type="button" class="btn btn-sm btn-link text-danger text-decoration-none" onclick="this.closest('li').remove()">Remove</button>
            </div>
        `;
        list.appendChild(li);
    });
}

function initSortable() {
    new Sortable(document.getElementById('menuList'), {
        animation: 150,
        ghostClass: 'bg-light'
    });
}

function addSelectedToMenu(chkClass) {
    document.querySelectorAll('.' + chkClass + ':checked').forEach(chk => {
        activeData.push({
            title: chk.dataset.title,
            url: chk.dataset.url
        });
        chk.checked = false;
    });
    renderMenu();
}

function addCustomToMenu() {
    const url = document.getElementById('customUrl').value;
    const text = document.getElementById('customText').value;
    if(url && text) {
        activeData.push({ title: text, url: url });
        document.getElementById('customText').value = '';
        renderMenu();
    }
}

function switchMenu(type) {
    window.location.href = '/admin/menus?menu=' + type;
}

function saveMenu() {
    const items = [];
    document.querySelectorAll('#menuList li').forEach(li => {
        items.push({
            title: li.dataset.title,
            url: li.dataset.url
        });
    });
    document.getElementById('menuDataOutput').value = JSON.stringify(items);
    document.getElementById('menuForm').submit();
}

// Init
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('menuTypeSelect').value = currentMenu;
    renderMenu();
    initSortable();
});
</script>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
