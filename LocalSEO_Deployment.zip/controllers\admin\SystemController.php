<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\UpdateChecker;
use Core\SiteHealth;

class SystemController extends Controller {
    public function updates() {
        $this->requireRole(['super_admin', 'admin']);
        
        $checker = new UpdateChecker();
        $info = $checker->check();

        $this->adminView('system/updates', [
            'pageTitle' => 'System Updates',
            'updateInfo' => $info
        ]);
    }

    public function processUpdate() {
        $this->requireRole(['super_admin']);
        $this->verifyCsrf();

        // Normally, this would trigger an asynchronous download/extraction process
        // For this implementation, we will mock a successful check
        $checker = new UpdateChecker();
        $info = $checker->check();

        if (!$info['has_update']) {
            \Core\Helpers::flash('success', 'You are already running the latest version.');
            $this->redirect('/admin/system/updates');
            return;
        }

        try {
            // $checker->downloadAndInstall($info['latest_version']); // Simulated
            
            \Core\Helpers::flash('success', 'Update downloaded and applied successfully. Database migrated.');
            $this->security->logActivity('system_update', $this->auth->user()['id'], 'system', null, "Updated CMS to {$info['latest_version']}");
            
            $db = \Core\Database::getInstance();
            $db->insert($db->t('update_history'), [
                'from_version' => LSEO_VERSION,
                'to_version' => $info['latest_version'],
                'update_type' => 'core',
                'status' => 'success',
                'completed_at' => date('Y-m-d H:i:s'),
                'updated_by' => $this->auth->user()['id'],
                'ip_address' => $this->security->getClientIP()
            ]);

        } catch (\Exception $e) {
            \Core\Helpers::flash('error', 'Update failed: ' . $e->getMessage());
        }

        $this->redirect('/admin/system/updates');
    }

    public function health() {
        $this->requireRole(['super_admin', 'admin']);
        
        $health = new SiteHealth();
        $report = $health->getReport();

        $this->adminView('system/health', [
            'pageTitle' => 'Site Health Status',
            'report' => $report
        ]);
    }

    public function logs() {
        $this->requireRole(['super_admin']);
        
        $db = \Core\Database::getInstance();
        $page = (int)$this->input('p', 1);
        $perPage = 50;
        $offset = ($page - 1) * $perPage;

        $type = $this->input('type', 'activity'); // activity or security
        
        if ($type === 'security') {
            $table = $db->t('security_log');
            $logs = $db->fetchAll("SELECT * FROM {$table} ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}");
            $total = $db->fetchColumn("SELECT COUNT(*) FROM {$table}");
        } else {
            $table = $db->t('activity_log');
            $logs = $db->fetchAll("SELECT a.*, u.display_name FROM {$table} a LEFT JOIN {$db->t('users')} u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT {$perPage} OFFSET {$offset}");
            $total = $db->fetchColumn("SELECT COUNT(*) FROM {$table}");
        }

        $pagination = [
            'current' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'last_page' => max((int)ceil($total / $perPage), 1)
        ];

        $this->adminView('system/logs', [
            'pageTitle' => ucfirst($type) . ' Logs',
            'type' => $type,
            'logs' => $logs,
            'pagination' => $pagination
        ]);
    }
}
