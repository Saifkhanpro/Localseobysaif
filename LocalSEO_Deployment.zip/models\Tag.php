<?php
namespace Models;
use Core\Model;

class Tag extends Model {
    protected $table = 'tags';
    protected $fillable = [
        'name', 'slug', 'description', 'seo_title', 'meta_description',
        'focus_keyword', 'robots_index', 'robots_follow', 'canonical_url'
    ];

    public function getWithCount(): array {
        $sql = "SELECT t.*, (SELECT COUNT(*) FROM {$this->db->t('post_tags')} pt JOIN {$this->db->t('posts')} p ON pt.post_id = p.id WHERE pt.tag_id = t.id AND p.status='published') as post_count 
                FROM {$this->table} t ORDER BY t.name ASC";
        return $this->db->fetchAll($sql);
    }

    public function getOrCreate(array $names): array {
        $ids = [];
        foreach ($names as $name) {
            $name = trim($name);
            if (empty($name)) continue;
            
            $slug = \Core\Helpers::generateSlug($name);
            $existing = $this->first("slug = ?", [$slug]);
            
            if ($existing) {
                $ids[] = $existing['id'];
            } else {
                $ids[] = $this->create(['name' => $name, 'slug' => $slug]);
            }
        }
        return $ids;
    }
}
