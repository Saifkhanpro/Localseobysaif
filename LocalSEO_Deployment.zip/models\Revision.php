<?php
namespace Models;
use Core\Model;

class Revision extends Model {
    protected $table = 'post_revisions';
    protected $fillable = ['post_id', 'author_id', 'title', 'content', 'excerpt', 'reason'];
}
