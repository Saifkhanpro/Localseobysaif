<?php
namespace Core;

class Controller {
    protected $db;
    protected $auth;
    protected $security;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->auth = new Auth();
        $this->security = new Security();
    }

    protected function view(string $view, array $data = []): void {
        extract($data);
        $auth = $this->auth;
        $settings = $GLOBALS['settings'] ?? [];
        $viewFile = VIEW_PATH . '/' . $view . '.php';
        if (!file_exists($viewFile)) {
            if (defined('APP_DEBUG') && APP_DEBUG) die("View not found: {$viewFile}");
            die('Page not found.');
        }
        require $viewFile;
    }

    protected function adminView(string $view, array $data = []): void {
        $data['auth'] = $this->auth;
        $data['currentUser'] = $this->auth->user();
        $data['settings'] = $GLOBALS['settings'] ?? [];
        $data['pageTitle'] = $data['pageTitle'] ?? 'Dashboard';
        extract($data);
        $viewFile = VIEW_PATH . '/admin/' . $view . '.php';
        if (!file_exists($viewFile)) {
            if (defined('APP_DEBUG') && APP_DEBUG) die("Admin view not found: {$viewFile}");
            die('Page not found.');
        }
        ob_start();
        require $viewFile;
        $content = ob_get_clean();
        require VIEW_PATH . '/layouts/admin.php';
    }

    protected function frontendView(string $view, array $data = []): void {
        $data['settings'] = $GLOBALS['settings'] ?? [];
        extract($data);
        ob_start();
        require VIEW_PATH . '/frontend/' . $view . '.php';
        $content = ob_get_clean();
        require VIEW_PATH . '/layouts/frontend.php';
    }

    protected function json(array $data, int $code = 200): void {
        Helpers::jsonResponse($data, $code);
    }

    protected function redirect(string $url, int $code = 302): void {
        Helpers::redirect($url, $code);
    }

    protected function back(): void {
        Helpers::back();
    }

    protected function validate(array $rules): array {
        $validator = new Validator();
        return $validator->validate($_POST, $rules);
    }

    protected function input(string $key, $default = null) {
        return $_POST[$key] ?? $_GET[$key] ?? $default;
    }

    protected function inputAll(): array {
        return array_merge($_GET, $_POST);
    }

    protected function isAjax(): bool {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
    }

    protected function requireAdmin(): void {
        $this->auth->requireAuth();
    }

    protected function requireRole(array $roles): void {
        $this->auth->requireRole($roles);
    }

    protected function canAccess(string $permission): bool {
        return $this->auth->canAccess($permission);
    }

    protected function verifyCsrf(): void {
        if (!CSRF::verify()) {
            if ($this->isAjax()) {
                $this->json(['error' => 'Invalid security token. Please refresh.'], 403);
            }
            Helpers::flash('error', 'Security token expired. Please try again.');
            $this->back();
        }
    }

    protected function setting(string $key, $default = ''): string {
        return Helpers::setting($key, $default);
    }
}
