<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
    <a href="/admin/pages/create" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Add New Page</a>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="card-body border-bottom d-flex gap-2 py-2 bg-light rounded-top">
        <div class="d-flex gap-3 text-muted small align-items-center">
            <span class="text-dark fw-bold">All (<?= $counts['all'] ?>)</span> | 
            <span class="text-success">Published (<?= $counts['published'] ?>)</span> | 
            <span class="text-warning">Drafts (<?= $counts['draft'] ?>)</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>SEO Score</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($pages)): ?>
                    <tr><td colspan="4" class="text-center py-5 text-muted">No pages found.</td></tr>
                <?php else: ?>
                    <?php foreach($pages as $page): ?>
                        <tr>
                            <td>
                                <div class="fw-bold mb-1">
                                    <?php echo str_repeat('&mdash; ', $page['level']); ?>
                                    <?= htmlspecialchars($page['title']) ?>
                                    <?php if($page['status'] !== 'published'): ?>
                                        <span class="badge bg-secondary ms-1"><?= ucfirst($page['status']) ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="small ms-<?= $page['level'] * 3 ?>">
                                    <a href="/admin/pages/edit/<?= $page['id'] ?>" class="text-primary text-decoration-none me-2">Edit</a>
                                    <a href="/<?= $page['slug'] ?>" target="_blank" class="text-muted text-decoration-none me-2">View</a>
                                </div>
                            </td>
                            <td><?= htmlspecialchars($page['display_name'] ?? 'System') ?></td>
                            <td>
                                <?php 
                                $s = $page['seo_score'];
                                $col = $s >= 80 ? 'success' : ($s >= 50 ? 'warning' : 'danger');
                                ?>
                                <span class="badge bg-<?= $col ?> bg-opacity-10 text-<?= $col ?> border border-<?= $col ?>"><?= $s ?>/100</span>
                            </td>
                            <td class="small text-muted">
                                <?php 
                                if ($page['status'] === 'published') {
                                    echo 'Published<br>' . date('Y/m/d', strtotime($page['published_at']));
                                } else {
                                    echo 'Modified<br>' . date('Y/m/d', strtotime($page['updated_at']));
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
