<?php
namespace Models;
use Core\Model;

class BlockedIp extends Model {
    protected $table = 'blocked_ips';
    protected $fillable = ['ip_address', 'reason', 'attempts', 'blocked_until', 'is_permanent'];
}
