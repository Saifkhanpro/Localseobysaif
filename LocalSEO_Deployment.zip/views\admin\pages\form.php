<?php ob_start(); ?>

<form method="POST" action="/admin/pages/save">
    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
    <input type="hidden" name="id" value="<?= $page['id'] ?? 0 ?>">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save Page</button>
    </div>

    <div class="row g-4">
        <!-- Main Content Area -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Page Title</label>
                        <input type="text" name="title" class="form-control form-control-lg" required value="<?= htmlspecialchars($page['title'] ?? '') ?>">
                        <?php if(isset($page['slug'])): ?>
                            <div class="form-text mt-2"><i class="bi bi-link-45deg"></i> Permalink: <strong><?= rtrim(APP_URL, '/') ?>/<?= htmlspecialchars($page['slug']) ?></strong></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold">Page Content</label>
                        <textarea name="content" class="wysiwyg form-control"><?= htmlspecialchars($page['content'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <!-- SEO Module box -->
            <div class="card border-0 shadow-sm mb-4 border-top border-primary border-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0 text-primary"><i class="bi bi-search me-2"></i> SEO Parameters</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Focus Keyword</label>
                        <input type="text" name="focus_keyword" class="form-control" value="<?= htmlspecialchars($page['focus_keyword'] ?? '') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">SEO Title</label>
                        <input type="text" name="seo_title" class="form-control" value="<?= htmlspecialchars($page['seo_title'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="3"><?= htmlspecialchars($page['meta_description'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- Sidebar Area -->
        <div class="col-lg-4">
            <!-- Publishing Box -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Publishing</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Status</label>
                        <select name="status" class="form-select">
                            <option value="draft" <?= ($page['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="published" <?= ($page['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Template</label>
                        <select name="template" class="form-select">
                            <option value="default" <?= ($page['template'] ?? 'default') === 'default' ? 'selected' : '' ?>>Default Template</option>
                            <option value="fullwidth" <?= ($page['template'] ?? '') === 'fullwidth' ? 'selected' : '' ?>>Full Width</option>
                            <option value="landing" <?= ($page['template'] ?? '') === 'landing' ? 'selected' : '' ?>>Landing Page (No Header/Footer)</option>
                            <option value="contact" <?= ($page['template'] ?? '') === 'contact' ? 'selected' : '' ?>>Contact Form Layout</option>
                        </select>
                    </div>
                </div>
                <div class="card-footer bg-light text-end">
                    <button type="submit" class="btn btn-primary w-100">Save Page</button>
                </div>
            </div>

            <!-- Page Attributes -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Page Attributes</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Parent Page</label>
                        <select name="parent_id" class="form-select">
                            <option value="0">(no parent)</option>
                            <?php foreach($parents as $p): ?>
                                <?php if(($page['id'] ?? 0) === $p['id']) continue; ?>
                                <option value="<?= $p['id'] ?>" <?= ($page['parent_id'] ?? 0) == $p['id'] ? 'selected' : '' ?>>
                                    <?= str_repeat('&mdash; ', $p['level']) . htmlspecialchars($p['title']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Order (Menu priority)</label>
                        <input type="number" name="order_index" class="form-control" value="<?= $page['order_index'] ?? 0 ?>">
                    </div>
                </div>
            </div>

            <!-- Featured Image -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Featured Image</div>
                <div class="card-body text-center">
                    <input type="hidden" name="featured_image_id" id="featured_image_id" value="<?= $page['featured_image_id'] ?? '' ?>">
                    <div id="image-preview" class="mb-3 <?= empty($featuredImageUrl) ? 'd-none' : '' ?>">
                        <img src="<?= htmlspecialchars($featuredImageUrl ?? '') ?>" class="img-fluid rounded border">
                    </div>
                    <button type="button" class="btn btn-outline-secondary w-100" onclick="alert('Media Selection');"><i class="bi bi-image"></i> Set Image</button>
                </div>
            </div>
            
        </div>
    </div>
</form>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
