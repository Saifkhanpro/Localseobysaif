<?php
namespace Models;
use Core\Model;

class SEOData extends Model {
    protected $table = 'seo_data';
    protected $fillable = [
        'url_path', 'focus_keyword', 'secondary_keywords', 'seo_title',
        'meta_description', 'robots_index', 'robots_follow', 'robots_advanced',
        'canonical_url', 'og_title', 'og_description', 'og_image_id',
        'twitter_title', 'twitter_description', 'twitter_image_id',
        'schema_type', 'schema_data', 'readability_score', 'seo_score'
    ];

    public function findByUrl(string $url): ?array {
        return $this->first("url_path = ?", [$url]);
    }
}
