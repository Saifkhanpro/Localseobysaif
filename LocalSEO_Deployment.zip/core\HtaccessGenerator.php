<?php
namespace Core;

class HtaccessGenerator {
    public function generate(array $options = []): bool {
        $path = ROOT_PATH . '/.htaccess';
        $backup = BACKUP_PATH . '/.htaccess.' . time() . '.bak';
        if (file_exists($path)) {
            @copy($path, $backup);
        }

        $content = "# ============================================================\n";
        $content .= "# LocalSEO.pk — Auto-Generated Apache Configuration\n";
        $content .= "# Generated: " . date('Y-m-d H:i:s') . "\n";
        $content .= "# ============================================================\n\n";

        // Directory listing
        $content .= "Options -Indexes -Multiviews\nServerSignature Off\n\n";

        // Rewrites
        $content .= "<IfModule mod_rewrite.c>\n";
        $content .= "    RewriteEngine On\n";
        $content .= "    RewriteBase /\n\n";
        
        $content .= "    # Force HTTPS\n";
        $content .= "    RewriteCond %{HTTPS} !=on\n";
        $content .= "    RewriteCond %{HTTP_HOST} !^localhost [NC]\n";
        $content .= "    RewriteCond %{HTTP_HOST} !^127\.0\.0\.1 [NC]\n";
        $content .= "    RewriteRule ^(.*)$ https://%{HTTP_HOST}/$1 [R=301,L]\n\n";

        $content .= "    # Block access to app directories\n";
        $content .= "    RewriteRule ^config\.php$ - [F,L]\n";
        $content .= "    RewriteRule ^core/.*$ - [F,L]\n";
        $content .= "    RewriteRule ^models/.*$ - [F,L]\n";
        $content .= "    RewriteRule ^controllers/.*$ - [F,L]\n";
        $content .= "    RewriteRule ^views/.*$ - [F,L]\n";
        $content .= "    RewriteRule ^backups/.*$ - [F,L]\n";
        $content .= "    RewriteRule ^temp/.*$ - [F,L]\n";
        $content .= "    RewriteRule ^cache/(?!assets/).*$ - [F,L]\n\n";

        $content .= "    # Allow cache assets\n";
        $content .= "    RewriteRule ^cache/assets/.*\.(css|js)$ - [L]\n\n";

        $content .= "    # Sitemaps\n";
        $content .= "    RewriteRule ^sitemap\.xml$ sitemap.php [L]\n";
        $content .= "    RewriteRule ^([a-z0-9-]+)-sitemap\.xml$ sitemap.php?type=$1 [L,QSA]\n\n";

        $content .= "    RewriteRule ^robots\.txt$ index.php?route=robots [L,QSA]\n\n";

        $content .= "    # Static assets\n";
        $content .= "    RewriteCond %{REQUEST_URI} ^/(uploads|assets)/\n";
        $content .= "    RewriteCond %{REQUEST_FILENAME} -f\n";
        $content .= "    RewriteRule ^ - [L]\n\n";

        $content .= "    # Front controller\n";
        $content .= "    RewriteCond %{REQUEST_FILENAME} !-f\n";
        $content .= "    RewriteCond %{REQUEST_FILENAME} !-d\n";
        $content .= "    RewriteRule ^(.*)$ index.php [L,QSA]\n";
        $content .= "</IfModule>\n\n";

        // Security headers
        if (empty($options['disable_security_headers'])) {
            $content .= "<IfModule mod_headers.c>\n";
            $content .= "    Header set X-XSS-Protection \"1; mode=block\"\n";
            $content .= "    Header set X-Content-Type-Options \"nosniff\"\n";
            $content .= "    Header set X-Frame-Options \"SAMEORIGIN\"\n";
            $content .= "    Header set Referrer-Policy \"strict-origin-when-cross-origin\"\n";
            $content .= "    Header unset X-Powered-By\n";
            $content .= "    Header unset Server\n";
            $content .= "</IfModule>\n\n";
        }

        // Cache browser
        $content .= "<IfModule mod_expires.c>\n";
        $content .= "    ExpiresActive On\n";
        $content .= "    ExpiresDefault \"access plus 1 month\"\n";
        $content .= "    ExpiresByType text/html \"access plus 0 seconds\"\n";
        $content .= "    ExpiresByType text/css \"access plus 1 year\"\n";
        $content .= "    ExpiresByType application/javascript \"access plus 1 year\"\n";
        $content .= "    ExpiresByType image/jpeg \"access plus 1 year\"\n";
        $content .= "    ExpiresByType image/png \"access plus 1 year\"\n";
        $content .= "    ExpiresByType image/webp \"access plus 1 year\"\n";
        $content .= "</IfModule>\n\n";

        // Compression
        $content .= "<IfModule mod_deflate.c>\n";
        $content .= "    AddOutputFilterByType DEFLATE text/html text/plain text/css text/javascript application/javascript application/json\n";
        $content .= "</IfModule>\n\n";

        return @file_put_contents($path, $content) !== false;
    }
}
