<?php
namespace Core;

class UpdateChecker {
    private $serverUrl;
    
    public function __construct() {
        $this->serverUrl = defined('UPDATE_SERVER_URL') ? UPDATE_SERVER_URL : 'https://updates.localseo.pk/manifest.json';
    }

    public function check(bool $force = false): ?array {
        $db = Database::getInstance();
        $settings = $GLOBALS['settings'] ?? [];
        $lastCheck = (int)($settings['last_update_check'] ?? 0);
        $interval = (int)($settings['update_check_interval'] ?? 43200);

        if (!$force && (time() - $lastCheck) < $interval) {
            $cached = $settings['available_update_cached'] ?? null;
            return $cached ? json_decode($cached, true) : null;
        }

        $ch = curl_init($this->serverUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_USERAGENT => 'LocalSEO-CMS/' . (defined('APP_VERSION') ? APP_VERSION : '1.0.0'),
            CURLOPT_SSL_VERIFYPEER => false // Use true in pure PROD, false to avoid host issues
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $db->update($db->t('settings'), ['setting_value' => time()], "setting_key = 'last_update_check'");

        if ($httpCode !== 200 || !$response) {
            return null;
        }

        $data = json_decode($response, true);
        if (!$data || empty($data['version'])) return null;

        $currentVersion = defined('APP_VERSION') ? APP_VERSION : '1.0.0';
        if (version_compare($data['version'], $currentVersion, '>')) {
            $db->update($db->t('settings'), [
                'setting_value' => json_encode($data)
            ], "setting_key = 'available_update_cached'");
            
            $db->update($db->t('settings'), ['setting_value' => $data['version']], "setting_key = 'available_update_version'");

            // Optionally notify via email
            if ($force === false && ($settings['update_notify_email'] ?? '1') === '1') {
                if (($settings['update_email_security_only'] ?? '1') === '0' || $data['update_type'] === 'security') {
                    Mailer::sendUpdateNotification($data['version'], $data['update_type']);
                }
            }

            return $data;
        }

        $db->update($db->t('settings'), ['setting_value' => ''], "setting_key = 'available_update_cached'");
        $db->update($db->t('settings'), ['setting_value' => ''], "setting_key = 'available_update_version'");
        return null;
    }
}
