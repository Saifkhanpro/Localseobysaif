<?php
namespace Controllers\Admin;
use Core\Controller;
class ToolController extends Controller {
    public function __call($name, $arguments) {
        $this->requireAuth();
        echo "<h1>Under Construction</h1><p>Tools module ($name) is being built.</p>";
    }
}
