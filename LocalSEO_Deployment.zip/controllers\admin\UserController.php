<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;

class UserController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin']);
        
        $db = \Core\Database::getInstance();
        $users = $db->fetchAll("SELECT id, username, email, display_name, role, seo_role, is_active, last_login 
                                FROM {$db->t('users')} ORDER BY role DESC, display_name ASC");

        $this->adminView('users/index', [
            'pageTitle' => 'Users Administration',
            'users' => $users
        ]);
    }

    public function create() {
        $this->requireRole(['super_admin', 'admin']);
        $this->adminView('users/form', [
            'pageTitle' => 'Add New User',
            'user' => null
        ]);
    }

    public function edit(int $id) {
        $this->requireRole(['super_admin', 'admin']);
        
        $db = \Core\Database::getInstance();
        $user = $db->fetch("SELECT id, username, email, display_name, first_name, last_name, bio, website, role, seo_role, is_active FROM {$db->t('users')} WHERE id = ?", [$id]);

        if (!$user) {
            Helpers::flash('error', 'User not found.');
            $this->redirect('/admin/users');
            return;
        }

        $this->adminView('users/form', [
            'pageTitle' => 'Edit User',
            'user' => $user
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $db = \Core\Database::getInstance();

        $data = [
            'username' => trim($this->input('username')),
            'email' => trim($this->input('email')),
            'display_name' => trim($this->input('display_name')),
            'first_name' => trim($this->input('first_name', '')),
            'last_name' => trim($this->input('last_name', '')),
            'bio' => trim($this->input('bio', '')),
            'website' => trim($this->input('website', '')),
            'role' => $this->input('role', 'subscriber'),
            'seo_role' => $this->input('seo_role', 'none'),
            'is_active' => $this->input('is_active', 0) ? 1 : 0
        ];

        // Ensure current user doesn't demote themselves out of existence accidentally
        $currentUser = $this->auth->user();
        if ($id === (int)$currentUser['id']) {
            if ($data['role'] !== 'super_admin' && $currentUser['role'] === 'super_admin') {
                $data['role'] = 'super_admin'; // Prevent demotion
            }
            if ($data['is_active'] === 0) {
                $data['is_active'] = 1; // Prevent self-deactivation
            }
        }

        // Unique checks
        if ($id > 0) {
            $exists = $db->fetch("SELECT id FROM {$db->t('users')} WHERE (username = ? OR email = ?) AND id != ?", [$data['username'], $data['email'], $id]);
        } else {
            $exists = $db->fetch("SELECT id FROM {$db->t('users')} WHERE username = ? OR email = ?", [$data['username'], $data['email']]);
        }

        if ($exists) {
            Helpers::flash('error', 'Username or Email already exists.');
            $this->redirect($id > 0 ? '/admin/users/edit/'.$id : '/admin/users/create');
            return;
        }

        $password = $this->input('password');

        if ($id > 0) {
            if (!empty($password)) {
                $data['password'] = password_hash($password, PASSWORD_DEFAULT);
                // Invalidate sessions
                $data['session_token'] = null;
            }
            $db->update($db->t('users'), $data, "id=?", [$id]);
            Helpers::flash('success', 'User updated successfully.');
        } else {
            if (empty($password)) {
                Helpers::flash('error', 'Password is required for new users.');
                $this->redirect('/admin/users/create');
                return;
            }
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
            $db->insert($db->t('users'), $data);
            Helpers::flash('success', 'User created successfully.');
        }

        $this->redirect('/admin/users');
    }

    public function delete(int $id) {
        $this->requireRole(['super_admin']);
        
        $currentUser = $this->auth->user();
        if ($id === (int)$currentUser['id']) {
            Helpers::flash('error', 'You cannot delete yourself.');
            $this->redirect('/admin/users');
            return;
        }

        $db = \Core\Database::getInstance();
        $db->delete($db->t('users'), 'id=?', [$id]);
        
        Helpers::flash('success', 'User deleted entirely.');
        $this->redirect('/admin/users');
    }
}
