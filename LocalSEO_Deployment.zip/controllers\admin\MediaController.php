<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Media;
use Core\ImageProcessor;
use Core\ImageOptimizer;

class MediaController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor', 'author']);
        
        $mediaModel = new Media();
        $page = (int)$this->input('p', 1);
        $perPage = 40;

        $s = $this->input('s');
        $type = $this->input('type');
        
        $where = "1=1";
        $params = [];
        
        if ($s) {
            $where .= " AND (title LIKE ? OR original_name LIKE ?)";
            $params[] = "%{$s}%";
            $params[] = "%{$s}%";
        }
        
        if ($type) {
            $where .= " AND file_type = ?";
            $params[] = $type;
        }

        if (in_array($this->auth->user()['role'], ['author'])) {
            $where .= " AND uploaded_by = ?";
            $params[] = $this->auth->user()['id'];
        }

        $paginated = $mediaModel->paginate($page, $perPage, $where, $params, 'created_at DESC');

        $this->adminView('media/index', [
            'pageTitle' => 'Media Library',
            'media' => $paginated['items'],
            'pagination' => $paginated
        ]);
    }

    public function upload() {
        $this->requireRole(['super_admin', 'admin', 'editor', 'author']);
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_FILES['file'])) {
            if ($this->isAjax()) $this->json(['error'=>'No file provided'], 400);
            return $this->redirect('/admin/media');
        }

        $file = $_FILES['file'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            if ($this->isAjax()) $this->json(['error'=>'Upload failed error code: ' . $file['error']], 400);
            Helpers::flash('error', 'Upload failed.');
            return $this->redirect('/admin/media');
        }

        $maxSize = Helpers::setting('upload_max_size', 5) * 1024 * 1024;
        if ($file['size'] > $maxSize) {
            $err = 'File too large. Max allowed is ' . Helpers::setting('upload_max_size', 5) . 'MB.';
            if ($this->isAjax()) $this->json(['error'=>$err], 400);
            Helpers::flash('error', $err);
            return $this->redirect('/admin/media');
        }

        $allowedMimes = explode(',', Helpers::setting('upload_allowed_types', 'image/jpeg,image/png,image/gif,image/webp,application/pdf'));
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mime, $allowedMimes)) {
            $err = 'File type not allowed: ' . $mime;
            if ($this->isAjax()) $this->json(['error'=>$err], 400);
            Helpers::flash('error', $err);
            return $this->redirect('/admin/media');
        }

        $isImage = strpos($mime, 'image/') === 0;
        $destDir = ROOT_PATH . '/uploads/' . date('Y/m');
        if (!is_dir($destDir)) @mkdir($destDir, 0755, true);

        try {
            if ($isImage) {
                $processor = new ImageProcessor();
                $result = $processor->process($file['tmp_name'], $destDir);
                
                $data = [
                    'file_name' => $result['file_name'],
                    'original_name' => basename($file['name']),
                    'file_path' => 'uploads/' . date('Y/m') . '/' . $result['file_name'],
                    'file_type' => 'image',
                    'mime_type' => $mime,
                    'file_size' => $result['file_size'],
                    'title' => pathinfo($file['name'], PATHINFO_FILENAME),
                    'uploaded_by' => $this->auth->user()['id'],
                    'width' => $result['width'],
                    'height' => $result['height'],
                    'webp_path' => $result['webp_path'] ?? null
                ];
            } else {
                $baseName = pathinfo($file['name'], PATHINFO_FILENAME);
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $fileName = preg_replace('/[^a-z0-9_-]/', '-', strtolower($baseName)) . '-' . time() . '.' . $ext;
                $destPath = $destDir . '/' . $fileName;
                
                if (!move_uploaded_file($file['tmp_name'], $destPath)) {
                    throw new \Exception('Failed to move uploaded file.');
                }
                
                $data = [
                    'file_name' => $fileName,
                    'original_name' => basename($file['name']),
                    'file_path' => 'uploads/' . date('Y/m') . '/' . $fileName,
                    'file_type' => 'document',
                    'mime_type' => $mime,
                    'file_size' => filesize($destPath),
                    'title' => $baseName,
                    'uploaded_by' => $this->auth->user()['id']
                ];
            }

            $mediaModel = new Media();
            $id = $mediaModel->create($data);
            $data['id'] = $id;

            // Auto-optimize if enabled
            if ($isImage && Helpers::setting('image_auto_optimize', '1') === '1') {
                $optimizer = new ImageOptimizer();
                $optimizer->optimizeSingle($id);
            }

            if ($this->isAjax()) {
                $this->json(['success' => true, 'file' => $data]);
            } else {
                Helpers::flash('success', 'File uploaded successfully.');
                $this->redirect('/admin/media');
            }

        } catch (\Exception $e) {
            if ($this->isAjax()) $this->json(['error'=>$e->getMessage()], 500);
            Helpers::flash('error', $e->getMessage());
            $this->redirect('/admin/media');
        }
    }

    public function delete(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor', 'author']);
        
        $mediaModel = new Media();
        $media = $mediaModel->find($id);

        if (!$media) {
            $this->redirect('/admin/media');
            return;
        }

        if ($this->auth->user()['role'] === 'author' && $media['uploaded_by'] != $this->auth->user()['id']) {
            $this->redirect('/admin/media');
            return;
        }

        $mediaModel->deleteWithFiles($id);
        
        if ($this->isAjax()) {
            $this->json(['success' => true]);
        } else {
            Helpers::flash('success', 'File deleted successfully.');
            $this->redirect('/admin/media');
        }
    }
}
