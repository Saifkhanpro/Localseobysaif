<?php
namespace Core;

class Model {
    protected $db;
    protected $table;
    protected $primaryKey = 'id';
    protected $fillable = [];

    public function __construct() {
        $this->db = Database::getInstance();
        if ($this->table) {
            $this->table = $this->db->t($this->table);
        }
    }

    public function find(int $id): ?array {
        return $this->db->fetch("SELECT * FROM {$this->table} WHERE {$this->primaryKey} = ?", [$id]);
    }

    public function findBySlug(string $slug): ?array {
        return $this->db->fetch("SELECT * FROM {$this->table} WHERE slug = ?", [$slug]);
    }

    public function all(string $orderBy = 'id DESC'): array {
        return $this->db->fetchAll("SELECT * FROM {$this->table} ORDER BY {$orderBy}");
    }

    public function where(string $conditions, array $params = [], string $orderBy = 'id DESC'): array {
        return $this->db->fetchAll("SELECT * FROM {$this->table} WHERE {$conditions} ORDER BY {$orderBy}", $params);
    }

    public function first(string $conditions, array $params = []): ?array {
        return $this->db->fetch("SELECT * FROM {$this->table} WHERE {$conditions} LIMIT 1", $params);
    }

    public function paginate(int $page = 1, int $perPage = 12, string $conditions = '1=1', array $params = [], string $orderBy = 'id DESC'): array {
        $total = $this->db->count($this->table, $conditions, $params);
        $totalPages = max(1, (int) ceil($total / $perPage));
        $page = max(1, min($page, $totalPages));
        $offset = ($page - 1) * $perPage;
        $items = $this->db->fetchAll("SELECT * FROM {$this->table} WHERE {$conditions} ORDER BY {$orderBy} LIMIT {$perPage} OFFSET {$offset}", $params);
        return ['items' => $items, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'total_pages' => $totalPages, 'has_prev' => $page > 1, 'has_next' => $page < $totalPages];
    }

    public function create(array $data): int {
        $filtered = $this->filterFillable($data);
        return $this->db->insert($this->table, $filtered);
    }

    public function update(int $id, array $data): int {
        $filtered = $this->filterFillable($data);
        return $this->db->update($this->table, $filtered, "{$this->primaryKey} = ?", [$id]);
    }

    public function delete(int $id): int {
        return $this->db->delete($this->table, "{$this->primaryKey} = ?", [$id]);
    }

    public function count(string $conditions = '1=1', array $params = []): int {
        return $this->db->count($this->table, $conditions, $params);
    }

    public function exists(string $conditions, array $params = []): bool {
        return $this->count($conditions, $params) > 0;
    }

    protected function filterFillable(array $data): array {
        if (empty($this->fillable)) return $data;
        return array_intersect_key($data, array_flip($this->fillable));
    }

    public function getTable(): string {
        return $this->table;
    }
}
