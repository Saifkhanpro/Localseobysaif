<?php
namespace Core;

class LazyLoader {
    public function processHTML(string $html): string {
        $html = preg_replace('/<img(?![^>]*loading=)([^>]*?)>/i', '<img loading="lazy"$1>', $html);
        $html = preg_replace('/<iframe(?![^>]*loading=)([^>]*?)>/i', '<iframe loading="lazy"$1>', $html);
        return $html;
    }
}
