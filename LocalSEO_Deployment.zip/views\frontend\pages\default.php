<?php ob_start(); ?>

<?php 
// Header background logic
$headerBg = 'background-color: var(--primary-color);';
if ($page['featured_image_id']) {
    $db = \Core\Database::getInstance();
    $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$page['featured_image_id']]);
    if ($media) {
        $headerBg = "background-image: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.7)), url('/" . ltrim($media['file_path'], '/') . "'); background-size: cover; background-position: center;";
    }
}
?>

<div class="page-hero py-6 text-white text-center position-relative" style="<?= $headerBg ?>">
    <div class="container py-5 position-relative z-1">
        <h1 class="display-3 fw-bolder mb-3 text-white"><?= \Core\Helpers::escape($page['title']) ?></h1>
        <?php if (!empty($page['meta_description'])): ?>
            <p class="lead text-white-50 max-w-700 mx-auto mb-0"><?= \Core\Helpers::escape($page['meta_description']) ?></p>
        <?php endif; ?>
    </div>
</div>

<div class="container py-5 my-md-4">
    <div class="row justify-content-center">
        <div class="col-lg-10 col-xl-9">
            <article class="bg-white p-4 p-md-5 rounded-4 shadow-sm border mb-5 content-formatted fs-5">
                <?= $page['content'] ?>
            </article>
        </div>
    </div>
</div>

<style>
    .py-6 { padding-top: 6rem!important; padding-bottom: 6rem!important; }
    .max-w-700 { max-width: 700px; }
    .content-formatted h2 { margin-top: 2.5rem; margin-bottom: 1.25rem; font-weight: 800; color: #0f172a; font-size: 2.25rem; }
    .content-formatted h3 { margin-top: 2rem; margin-bottom: 1rem; font-weight: 700; color: #1e293b; font-size: 1.75rem;}
    .content-formatted p { line-height: 1.85; color: #334155; margin-bottom: 1.5rem; }
    .content-formatted ul, .content-formatted ol { margin-bottom: 1.5rem; padding-left: 2rem; }
    .content-formatted li { margin-bottom: 0.5rem; line-height: 1.85; color: #334155; }
    .content-formatted a { color: var(--primary-color); text-decoration: none; font-weight: 500; border-bottom: 1px solid transparent; transition: all 0.2s; }
    .content-formatted a:hover { border-bottom: 1px solid var(--primary-color); }
    .content-formatted img { max-width: 100%; height: auto; border-radius: 0.5rem; margin: 1.5rem 0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
