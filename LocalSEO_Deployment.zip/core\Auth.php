<?php
namespace Core;

class Auth {
    private $db;
    private $security;
    private $user = null;

    public function __construct() {
        $this->db = Database::getInstance();
        $this->security = new Security();
    }

    public function attempt(string $username, string $password): array {
        $t = $this->db->t('users');
        $ip = $this->security->getClientIP();
        $settings = $GLOBALS['settings'] ?? [];
        $maxAttempts = (int)($settings['login_max_attempts'] ?? 5);
        $lockDuration = (int)($settings['login_lockout_duration'] ?? 15);

        $user = $this->db->fetch("SELECT * FROM {$t} WHERE (username = ? OR email = ?) LIMIT 1", [$username, $username]);

        if (!$user) {
            $this->security->logSecurity('login_failed', null, $username, $ip);
            return ['success' => false, 'error' => 'Invalid credentials.'];
        }

        if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
            $mins = ceil((strtotime($user['locked_until']) - time()) / 60);
            return ['success' => false, 'error' => "Account locked. Try again in {$mins} minutes."];
        }

        if (!$user['is_active']) {
            return ['success' => false, 'error' => 'Account is deactivated.'];
        }

        if (!password_verify($password, $user['password'])) {
            $attempts = $user['login_attempts'] + 1;
            $data = ['login_attempts' => $attempts];
            if ($attempts >= $maxAttempts) {
                $data['locked_until'] = date('Y-m-d H:i:s', time() + ($lockDuration * 60));
                $this->security->logSecurity('account_locked', $user['id'], $user['username'], $ip, 'high');
            }
            $this->db->update($t, $data, 'id = ?', [$user['id']]);
            $this->security->logSecurity('login_failed', $user['id'], $user['username'], $ip);
            $remaining = $maxAttempts - $attempts;
            if ($remaining > 0 && $remaining <= 3) {
                return ['success' => false, 'error' => "Invalid credentials. {$remaining} attempts remaining."];
            }
            return ['success' => false, 'error' => 'Invalid credentials.'];
        }

        // Success
        $sessionToken = bin2hex(random_bytes(32));
        $this->db->update($t, [
            'login_attempts' => 0,
            'locked_until' => null,
            'last_login' => date('Y-m-d H:i:s'),
            'last_login_ip' => $ip,
            'last_activity' => date('Y-m-d H:i:s'),
            'session_token' => $sessionToken,
        ], 'id = ?', [$user['id']]);

        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['session_token'] = $sessionToken;
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['_created'] = time();

        $this->security->logSecurity('login_success', $user['id'], $user['username'], $ip, 'low');
        $this->security->logActivity('login', $user['id'], 'user', $user['id'], "User {$user['username']} logged in");

        return ['success' => true, 'user' => $user];
    }

    public function check(): bool {
        if (empty($_SESSION['user_id']) || empty($_SESSION['session_token'])) return false;
        $user = $this->user();
        if (!$user) return false;
        if ($user['session_token'] !== $_SESSION['session_token']) {
            $this->logout();
            return false;
        }
        $timeout = (int)($GLOBALS['settings']['session_timeout'] ?? 120) * 60;
        if ($user['last_activity'] && (time() - strtotime($user['last_activity'])) > $timeout) {
            $this->logout();
            return false;
        }
        $this->db->update($this->db->t('users'), ['last_activity' => date('Y-m-d H:i:s')], 'id = ?', [$user['id']]);
        return true;
    }

    public function user(): ?array {
        if ($this->user) return $this->user;
        if (empty($_SESSION['user_id'])) return null;
        $this->user = $this->db->fetch("SELECT * FROM {$this->db->t('users')} WHERE id = ? AND is_active = 1", [$_SESSION['user_id']]);
        return $this->user;
    }

    public function requireAuth(): void {
        if (!$this->check()) { Helpers::redirect('/admin/login'); }
    }

    public function requireRole(array $roles): void {
        $this->requireAuth();
        $user = $this->user();
        if (!in_array($user['role'], $roles)) {
            http_response_code(403);
            require VIEW_PATH . '/admin/403.php';
            exit;
        }
    }

    public function hasRole(string $role): bool {
        $user = $this->user();
        if (!$user) return false;
        $hierarchy = ['super_admin' => 6, 'admin' => 5, 'editor' => 4, 'author' => 3, 'contributor' => 2, 'subscriber' => 1];
        return ($hierarchy[$user['role']] ?? 0) >= ($hierarchy[$role] ?? 99);
    }

    public function canAccess(string $permission): bool {
        $user = $this->user();
        if (!$user) return false;
        $role = $user['role'];
        $perms = [
            'super_admin' => ['*'],
            'admin' => ['posts','pages','services','cities','media','comments','categories','tags','testimonials','case_studies','team','leads','users','redirects','seo','sitemap','cache','tools'],
            'editor' => ['posts','pages','services','cities','media','comments','categories','tags','testimonials','case_studies','team','leads'],
            'author' => ['posts','media','comments'],
            'contributor' => ['posts'],
            'subscriber' => [],
        ];
        $allowed = $perms[$role] ?? [];
        return in_array('*', $allowed) || in_array($permission, $allowed);
    }

    public function logout(): void {
        $user = $this->user();
        if ($user) {
            $this->security->logSecurity('logout', $user['id'], $user['username'], $this->security->getClientIP(), 'low');
            $this->db->update($this->db->t('users'), ['session_token' => null], 'id = ?', [$user['id']]);
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }

    public function id(): ?int {
        return $_SESSION['user_id'] ?? null;
    }
}
