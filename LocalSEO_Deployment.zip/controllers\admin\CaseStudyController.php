<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\CaseStudy;

class CaseStudyController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $csModel = new CaseStudy();
        $db = \Core\Database::getInstance();
        $page = (int)$this->input('p', 1);
        $perPage = 20;
        
        $where = "post_type = 'case_study'";
        $params = [];
        
        $s = $this->input('s');
        if ($s) {
            $where .= " AND title LIKE ?";
            $params[] = "%{$s}%";
        }

        $status = $this->input('status');
        if ($status && in_array($status, ['published', 'draft', 'trash'])) {
            $where .= " AND status = ?";
            $params[] = $status;
        } elseif (!$status) {
            $where .= " AND status != 'trash'";
        }

        $paginated = $csModel->paginate($page, $perPage, $where, $params, "updated_at DESC");

        // Attach authors
        foreach ($paginated['items'] as &$item) {
            $item['author'] = $db->fetchColumn("SELECT display_name FROM {$db->t('users')} WHERE id = ?", [$item['author_id']]);
        }

        $this->adminView('case_studies/index', [
            'pageTitle' => 'Case Studies',
            'case_studies' => $paginated['items'],
            'pagination' => $paginated,
            'counts' => [
                'all' => $csModel->count("post_type='case_study' AND status != 'trash'"),
                'published' => $csModel->count("post_type='case_study' AND status='published'"),
                'draft' => $csModel->count("post_type='case_study' AND status='draft'"),
                'trash' => $csModel->count("post_type='case_study' AND status='trash'")
            ]
        ]);
    }

    public function create() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $this->adminView('case_studies/form', [
            'pageTitle' => 'Add New Case Study',
            'case_study' => null
        ]);
    }

    public function edit(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $csModel = new CaseStudy();
        $cs = $csModel->find($id);

        if (!$cs || $cs['post_type'] !== 'case_study') {
            Helpers::flash('error', 'Case study not found.');
            $this->redirect('/admin/case-studies');
            return;
        }

        $featuredImageUrl = '';
        if ($cs['featured_image_id']) {
            $db = \Core\Database::getInstance();
            $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$cs['featured_image_id']]);
            if ($media) $featuredImageUrl = '/' . $media['file_path'];
        }

        $this->adminView('case_studies/form', [
            'pageTitle' => 'Edit Case Study',
            'case_study' => $cs,
            'featuredImageUrl' => $featuredImageUrl
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $csModel = new CaseStudy();
        $user = $this->auth->user();

        if ($id > 0) {
            $existing = $csModel->find($id);
            if (!$existing) {
                Helpers::flash('error', 'Case study not found.');
                $this->redirect('/admin/case-studies');
                return;
            }
        }

        $title = $this->input('title');
        $slug = Helpers::generateUniqueSlug($this->input('slug') ?: $title, 'posts', $id);
        
        $status = $this->input('status', 'draft');
        $now = date('Y-m-d H:i:s');
        $publishedAt = $this->input('published_at');
        if ($status === 'published' && !$publishedAt) {
            $publishedAt = $now;
        }

        $data = [
            'author_id' => $id > 0 ? $existing['author_id'] : $user['id'],
            'title' => $title,
            'slug' => $slug,
            'content' => $_POST['content'] ?? '',
            'excerpt' => $this->input('excerpt', ''),
            'status' => $status,
            'post_type' => 'case_study',
            'visibility' => 'public',
            'featured_image_id' => $this->input('featured_image_id') ?: null,
            'focus_keyword' => $this->input('focus_keyword', ''),
            'seo_title' => $this->input('seo_title', ''),
            'meta_description' => $this->input('meta_description', ''),
            'robots_index' => $this->input('robots_index', 'default'),
            'robots_follow' => $this->input('robots_follow', 'default'),
            'canonical_url' => $this->input('canonical_url', ''),
            'client_name' => $this->input('client_name', ''),
            'industry' => $this->input('industry', ''),
            'results_summary' => $this->input('results_summary', ''),
            'schema_type' => 'Article'
        ];

        if ($status === 'published') $data['published_at'] = $publishedAt;

        if ($id > 0) {
            $csModel->update($id, $data);
            Helpers::flash('success', 'Case study updated successfully.');
        } else {
            $id = $csModel->create($data);
            Helpers::flash('success', 'Case study created successfully.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');

        $this->redirect('/admin/case-studies/edit/' . $id);
    }

    public function action() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $action = $this->input('action');
        $ids = (array)$this->input('ids', []);

        if (empty($ids) || empty($action)) {
            $this->redirect('/admin/case-studies');
            return;
        }

        $csModel = new CaseStudy();
        $count = 0;

        foreach ($ids as $id) {
            $id = (int)$id;
            if ($action === 'trash') {
                $csModel->update($id, ['status' => 'trash']);
                $count++;
            } elseif ($action === 'restore') {
                $csModel->update($id, ['status' => 'draft']);
                $count++;
            } elseif ($action === 'delete') {
                $csModel->delete($id);
                $count++;
            }
        }

        if ($count > 0) {
            $cm = new \Core\CacheMonitor();
            $cm->clearType('pages');
            Helpers::flash('success', "Bulk action '{$action}' applied to {$count} case studies.");
        }

        $this->redirect('/admin/case-studies');
    }
}
