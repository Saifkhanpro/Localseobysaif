<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-journal-code me-2 text-primary"></i> <?= $pageTitle ?></h2>
    
    <div class="btn-group shadow-sm">
        <a href="/admin/system/logs?type=activity" class="btn btn-<?= $type === 'activity' ? 'primary' : 'outline-primary' ?>">User Activity</a>
        <a href="/admin/system/logs?type=security" class="btn btn-<?= $type === 'security' ? 'primary' : 'outline-primary' ?>">Security Events</a>
    </div>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="table-responsive">
        <?php if($type === 'activity'): ?>
            <!-- Activity Log Table -->
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Entity</th>
                        <th>IP Address</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($logs)): ?>
                        <tr><td colspan="5" class="text-center py-5 text-muted">No activity logs found.</td></tr>
                    <?php else: ?>
                        <?php foreach($logs as $log): ?>
                            <tr>
                                <td class="small text-muted" style="white-space: nowrap;"><?= date('M j, Y H:i:s', strtotime($log['created_at'])) ?></td>
                                <td><span class="badge bg-light text-dark border"><i class="bi bi-person me-1"></i> <?= htmlspecialchars($log['display_name'] ?? 'System') ?></span></td>
                                <td><span class="fw-bold text-dark"><?= ucfirst(htmlspecialchars($log['action'])) ?></span></td>
                                <td>
                                    <?php if($log['entity_type']): ?>
                                        <span class="text-muted small"><?= ucfirst(htmlspecialchars($log['entity_type'])) ?> #<?= $log['entity_id'] ?></span><br>
                                    <?php endif; ?>
                                    <span class="small text-muted"><?= htmlspecialchars($log['description']) ?></span>
                                </td>
                                <td><code class="text-dark bg-light px-2 py-1 rounded small"><?= htmlspecialchars($log['ip_address'] ?? '--') ?></code></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php else: ?>
            <!-- Security Log Table -->
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Event Type</th>
                        <th>IP Target & User</th>
                        <th>Request Details</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($logs)): ?>
                        <tr><td colspan="5" class="text-center py-5 text-muted">No security events found.</td></tr>
                    <?php else: ?>
                        <?php foreach($logs as $log): ?>
                            <tr>
                                <td class="small text-muted" style="white-space: nowrap;"><?= date('M j, Y H:i:s', strtotime($log['created_at'])) ?></td>
                                <td>
                                    <?php 
                                        $col = 'warning';
                                        if(strpos($log['event_type'], 'firewall_block') !== false) $col = 'danger';
                                        if(strpos($log['event_type'], 'login_success') !== false) $col = 'success';
                                    ?>
                                    <span class="badge bg-<?= $col ?>"><?= htmlspecialchars($log['event_type']) ?></span>
                                </td>
                                <td>
                                    <code class="text-dark bg-light px-2 py-1 rounded d-block mb-1"><?= htmlspecialchars($log['ip_address']) ?></code>
                                    <span class="small text-muted"><?= htmlspecialchars($log['username'] ?? 'Guest') ?></span>
                                </td>
                                <td>
                                    <div class="small text-truncate" style="max-width: 300px;" title="<?= htmlspecialchars($log['request_uri']) ?>"><?= htmlspecialchars($log['request_uri']) ?></div>
                                    <div class="small text-muted text-truncate" style="max-width: 300px;" title="<?= htmlspecialchars($log['user_agent']) ?>"><?= htmlspecialchars($log['user_agent']) ?></div>
                                </td>
                                <td>
                                    <?php if($log['status'] === 'blocked'): ?>
                                        <span class="text-danger fw-bold small"><i class="bi bi-shield-slash-fill me-1"></i> Blocked</span>
                                    <?php else: ?>
                                        <span class="text-success fw-bold small"><i class="bi bi-shield-check me-1"></i> Allowed</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    
    <?php if($pagination['last_page'] > 1): ?>
    <div class="card-footer bg-white py-3">
        <nav>
            <ul class="pagination pagination-sm mb-0 justify-content-end">
                <?php for($i=1; $i<=$pagination['last_page']; $i++): ?>
                    <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                        <a class="page-link" href="?type=<?= $type ?>&p=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
