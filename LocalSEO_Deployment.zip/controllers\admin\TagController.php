<?php
namespace Controllers\Admin;

use Core\Controller;
use Core\Helpers;
use Models\Tag;

class TagController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $tagModel = new Tag();
        $page = (int)$this->input('p', 1);
        $perPage = 50;
        
        $where = "1=1";
        $params = [];
        $s = $this->input('s');
        if ($s) {
            $where .= " AND name LIKE ?";
            $params[] = "%{$s}%";
        }

        $paginated = $tagModel->paginate($page, $perPage, $where, $params, "name ASC");

        $this->adminView('tags/index', [
            'pageTitle' => 'Manage Tags',
            'tags' => $paginated['items'],
            'pagination' => $paginated
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $tagModel = new Tag();

        $name = trim($this->input('name'));
        if (empty($name)) {
            Helpers::flash('error', 'Tag name is required.');
            $this->redirect('/admin/tags');
            return;
        }

        $slug = Helpers::generateUniqueSlug($this->input('slug') ?: $name, 'tags', $id);

        $data = [
            'name' => $name,
            'slug' => $slug,
            'description' => $this->input('description', ''),
            'seo_title' => $this->input('seo_title', ''),
            'meta_description' => $this->input('meta_description', ''),
            'focus_keyword' => $this->input('focus_keyword', ''),
            'robots_index' => $this->input('robots_index', 'default'),
            'robots_follow' => $this->input('robots_follow', 'default'),
            'canonical_url' => $this->input('canonical_url', '')
        ];

        if ($id > 0) {
            $tagModel->update($id, $data);
            Helpers::flash('success', 'Tag updated successfully.');
        } else {
            $tagModel->create($data);
            Helpers::flash('success', 'Tag created successfully.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        $this->redirect('/admin/tags');
    }

    public function delete(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $tagModel = new Tag();
        $db = \Core\Database::getInstance();
        
        $tag = $tagModel->find($id);
        if ($tag) {
            $db->delete($db->t('post_tags'), 'tag_id=?', [$id]);
            $tagModel->delete($id);
            Helpers::flash('success', 'Tag deleted successfully.');
            
            $cm = new \Core\CacheMonitor();
            $cm->clearType('pages');
        }
        $this->redirect('/admin/tags');
    }
}
