<?php
namespace Models;
use Core\Model;

class Setting extends Model {
    protected $table = 'settings';
    protected $fillable = ['setting_group', 'setting_key', 'setting_value', 'is_autoload'];

    public function getAllAutoload(): array {
        $rows = $this->db->fetchAll("SELECT setting_key, setting_value FROM {$this->table} WHERE is_autoload = 1");
        $settings = [];
        foreach ($rows as $row) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
        return $settings;
    }

    public function getAllGrouped(): array {
        $rows = $this->all('setting_group ASC, setting_key ASC');
        $grouped = [];
        foreach ($rows as $row) {
            if (!isset($grouped[$row['setting_group']])) {
                $grouped[$row['setting_group']] = [];
            }
            $grouped[$row['setting_group']][$row['setting_key']] = $row['setting_value'];
        }
        return $grouped;
    }

    public function set(string $key, string $value, string $group = 'general', bool $autoload = true): bool {
        $existing = $this->first("setting_key = ?", [$key]);
        if ($existing) {
            return $this->update($existing['id'], ['setting_value' => $value]) > 0;
        }
        return $this->create([
            'setting_group' => $group,
            'setting_key' => $key,
            'setting_value' => $value,
            'is_autoload' => $autoload ? 1 : 0
        ]) > 0;
    }
}
