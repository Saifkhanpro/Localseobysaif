<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Redirect;

class SeoController extends Controller {
    public function autoLinks() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $db = \Core\Database::getInstance();
        $links = $db->fetchAll("SELECT * FROM {$db->t('seo_auto_links')} ORDER BY priority ASC");

        $this->adminView('seo/auto_links', [
            'pageTitle' => 'SEO Auto-Link Automation',
            'links' => $links
        ]);
    }

    public function saveAutoLink() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $db = \Core\Database::getInstance();
        $id = (int)$this->input('id', 0);
        
        $data = [
            'keyword' => trim($this->input('keyword')),
            'target_url' => trim($this->input('target_url')),
            'priority' => (int)$this->input('priority', 10),
            'max_links_per_post' => (int)$this->input('max_links_per_post', 1),
            'exclude_posts' => $this->input('exclude_posts', ''),
            'is_active' => $this->input('is_active', 0) ? 1 : 0
        ];

        if (empty($data['keyword']) || empty($data['target_url'])) {
            Helpers::flash('error', 'Keyword and Target URL are required.');
            $this->redirect('/admin/seo/auto-links');
            return;
        }

        if ($id > 0) {
            $db->update($db->t('seo_auto_links'), $data, "id=?", [$id]);
            Helpers::flash('success', 'Rule updated.');
        } else {
            $db->insert($db->t('seo_auto_links'), $data);
            Helpers::flash('success', 'Rule added.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages'); // Content has changed!
        
        $this->redirect('/admin/seo/auto-links');
    }

    public function redirects() {
        $this->requireRole(['super_admin', 'admin']);
        
        $redirectModel = new Redirect();
        $page = (int)$this->input('p', 1);
        $perPage = 30;

        $paginated = $redirectModel->paginate($page, $perPage, "1=1", [], "created_at DESC");

        $this->adminView('seo/redirects', [
            'pageTitle' => '301 Redirect Manager',
            'redirects' => $paginated['items'],
            'pagination' => $paginated
        ]);
    }

    public function saveRedirect() {
        $this->requireRole(['super_admin', 'admin']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $redirectModel = new Redirect();

        $data = [
            'old_url' => trim($this->input('old_url')),
            'new_url' => trim($this->input('new_url')),
            'type' => (int)$this->input('type', 301),
            'match_type' => $this->input('match_type', 'exact'),
            'is_active' => $this->input('is_active', 0) ? 1 : 0
        ];

        if (empty($data['old_url']) || empty($data['new_url'])) {
            Helpers::flash('error', 'Old and New URLs are required.');
            $this->redirect('/admin/seo/redirects');
            return;
        }

        if ($id > 0) {
            $redirectModel->update($id, $data);
            Helpers::flash('success', 'Redirect updated.');
        } else {
            $redirectModel->create($data);
            Helpers::flash('success', 'Redirect created.');
        }

        $cm = new \Core\CacheMonitor();
        $cm->clearType('pages');
        
        $this->redirect('/admin/seo/redirects');
    }

    public function deleteRedirect(int $id) {
        $this->requireRole(['super_admin', 'admin']);
        $redirectModel = new Redirect();
        $redirectModel->delete($id);
        Helpers::flash('success', 'Redirect deleted.');
        $this->redirect('/admin/seo/redirects');
    }
}
