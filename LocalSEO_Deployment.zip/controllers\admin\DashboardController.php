<?php
namespace Controllers\Admin;
use Core\Controller;
use Models\Post;
use Models\Lead;
use Models\CityPage;
use Models\Service;

class DashboardController extends Controller {
    public function index() {
        $this->requireAuth();
        
        $postModel = new Post();
        $leadModel = new Lead();
        $cityModel = new CityPage();
        $serviceModel = new Service();
        $db = \Core\Database::getInstance();

        // Stats
        $stats = [
            'posts' => $postModel->count("status = 'published'"),
            'leads_total' => $leadModel->count(),
            'leads_unread' => $leadModel->getUnreadCount(),
            'cities' => $cityModel->count("status = 'published'"),
            'services' => $serviceModel->count("status = 'published'"),
            'pages' => $db->count($db->t('pages'), "status = 'published'"),
            'users' => $db->count($db->t('users'), "is_active = 1")
        ];

        // Recent Activity
        $recentLeads = $leadModel->where("1=1", [], "created_at DESC LIMIT 5");
        $recentActivity = $db->fetchAll("SELECT a.*, u.display_name FROM {$db->t('activity_log')} a LEFT JOIN {$db->t('users')} u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 8");
        
        // System Health (cached briefly)
        $healthCache = new \Core\ObjectCache();
        $healthScore = $healthCache->remember('dashboard_health_score', 3600, function() {
            $hlt = new \Core\SiteHealth();
            return $hlt->getReport()['score'];
        });

        // Updates
        $updateChecker = new \Core\UpdateChecker();
        $updateInfo = $updateChecker->check();

        $this->adminView('dashboard', [
            'pageTitle' => 'Dashboard',
            'stats' => $stats,
            'recentLeads' => $recentLeads,
            'recentActivity' => $recentActivity,
            'healthScore' => $healthScore,
            'updateInfo' => $updateInfo
        ]);
    }
}
