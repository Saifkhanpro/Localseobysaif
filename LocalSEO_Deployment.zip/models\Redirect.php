<?php
namespace Models;
use Core\Model;

class Redirect extends Model {
    protected $table = 'redirects';
    protected $fillable = [
        'old_url', 'new_url', 'type', 'match_type', 'is_active', 'hits', 'last_accessed'
    ];

    public function incrementHits(int $id): void {
        $this->db->query("UPDATE {$this->table} SET hits = hits + 1, last_accessed = NOW() WHERE id = ?", [$id]);
    }

    public function findMatch(string $url): ?array {
        // Exact match
        $exact = $this->first("old_url = ? AND match_type = 'exact' AND is_active = 1", [$url]);
        if ($exact) return $exact;
        
        // Exact match ignoring case and trailing slashes
        $trimmedUrl = rtrim(strtolower($url), '/');
        $ignoreStr = "LOWER(Trim(TRAILING '/' FROM old_url)) = ? AND match_type = 'exact_ignore' AND is_active = 1";
        $ignore = $this->first($ignoreStr, [$trimmedUrl]);
        if ($ignore) return $ignore;

        // Regex
        $regexes = $this->where("match_type = 'regex' AND is_active = 1");
        foreach ($regexes as $r) {
            $pattern = '@' . str_replace('@', '\@', $r['old_url']) . '@i';
            if (@preg_match($pattern, $url, $matches)) {
                if (strpos($r['new_url'], '$') !== false) {
                    $r['new_url'] = preg_replace($pattern, $r['new_url'], $url);
                }
                return $r;
            }
        }

        // Starts with
        $startsWith = $this->where("match_type = 'begins_with' AND is_active = 1", [], "LENGTH(old_url) DESC");
        foreach ($startsWith as $r) {
            if (strpos($url, $r['old_url']) === 0) {
                // Append the rest of the url
                $rest = substr($url, strlen($r['old_url']));
                $r['new_url'] = rtrim($r['new_url'], '/') . '/' . ltrim($rest, '/');
                return $r;
            }
        }

        // Contains
        $contains = $this->where("match_type = 'contains' AND is_active = 1");
        foreach ($contains as $r) {
            if (strpos($url, $r['old_url']) !== false) return $r;
        }

        return null; // No match
    }
}
