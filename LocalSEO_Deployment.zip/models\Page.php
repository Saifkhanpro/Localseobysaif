<?php
namespace Models;
use Core\Model;

class Page extends Model {
    protected $table = 'pages';
    protected $fillable = [
        'author_id', 'title', 'slug', 'content', 'status', 'visibility',
        'password', 'featured_image_id', 'parent_id', 'template', 'order_index',
        'focus_keyword', 'secondary_keywords', 'seo_title', 'meta_description',
        'robots_index', 'robots_follow', 'robots_advanced', 'canonical_url',
        'readability_score', 'seo_score', 'schema_type', 'schema_data',
        'published_at'
    ];

    public function getTree(int $parentId = null): array {
        $sql = "SELECT p.*, u.display_name 
                FROM {$this->table} p
                LEFT JOIN {$this->db->t('users')} u ON p.author_id = u.id";
        
        $params = [];
        if ($parentId !== null) {
            $sql .= " WHERE p.parent_id = ?";
            $params[] = $parentId;
        } else {
            $sql .= " WHERE p.parent_id IS NULL";
        }
        $sql .= " ORDER BY p.order_index ASC, p.title ASC";
        
        $pages = $this->db->fetchAll($sql, $params);
        foreach ($pages as &$page) {
            $page['children'] = $this->getTree($page['id']);
        }
        return $pages;
    }

    public function getIdsFlatTree(): array {
        $tree = $this->getTree();
        $flat = [];
        $flatten = function($items, $level = 0) use (&$flatten, &$flat) {
            foreach ($items as $item) {
                $item['level'] = $level;
                $flat[] = $item;
                if (!empty($item['children'])) $flatten($item['children'], $level + 1);
            }
        };
        $flatten($tree);
        return $flat;
    }
}
