<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
</div>

<div class="row g-4">
    <div class="col-lg-3">
        <div class="card bg-white shadow-sm border-0 position-sticky" style="top: 2rem;">
            <div class="list-group list-group-flush rounded-3 text-start">
                <a href="#general" class="list-group-item border-0 py-3 active rounded-top" data-bs-toggle="list"><i class="bi bi-sliders me-2"></i> General</a>
                <a href="#company" class="list-group-item border-0 py-3" data-bs-toggle="list"><i class="bi bi-building me-2"></i> Company Info</a>
                <a href="#contact" class="list-group-item border-0 py-3" data-bs-toggle="list"><i class="bi bi-envelope-at me-2"></i> Contact & APIs</a>
                <a href="#seo" class="list-group-item border-0 py-3" data-bs-toggle="list"><i class="bi bi-search me-2"></i> SEO Core</a>
                <a href="#performance" class="list-group-item border-0 py-3 rounded-bottom" data-bs-toggle="list"><i class="bi bi-lightning-charge me-2"></i> Performance</a>
            </div>
        </div>
    </div>

    <div class="col-lg-9">
        <form method="POST" action="/admin/settings/save" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            <input type="hidden" name="group" id="activeGroup" value="general">
            
            <div class="tab-content">
                <!-- General Settings -->
                <div class="tab-pane fade show active" id="general">
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-white fw-bold py-3"><i class="bi bi-sliders me-2 text-primary"></i> General Settings</div>
                        <div class="card-body">
                            <div class="mb-4">
                                <label class="form-label fw-bold">Site Title</label>
                                <input type="text" name="settings[site_title]" class="form-control" value="<?= htmlspecialchars($settings['general']['site_title'] ?? 'LocalSEO.pk') ?>">
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-bold">Tagline</label>
                                <input type="text" name="settings[site_tagline]" class="form-control" value="<?= htmlspecialchars($settings['general']['site_tagline'] ?? '') ?>">
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-bold">Admin Email Address</label>
                                <input type="email" name="settings[admin_email]" class="form-control" value="<?= htmlspecialchars($settings['general']['admin_email'] ?? '') ?>">
                                <div class="form-text">System notifications and lead alerts will be sent here.</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Company Info -->
                <div class="tab-pane fade" id="company">
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-white fw-bold py-3"><i class="bi bi-building me-2 text-primary"></i> Company Information Schema</div>
                        <div class="card-body bg-light text-muted small mb-3 rounded border mx-3 mt-3">
                            This data heavily influences the <strong>LocalBusiness</strong> JSON-LD schema injected automatically on all pages. Perfect accuracy here is required for Google Knowledge Panel generation.
                        </div>
                        <div class="card-body pt-0">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Company Legal Name</label>
                                <input type="text" name="settings[company_name]" class="form-control" value="<?= htmlspecialchars($settings['company']['company_name'] ?? '') ?>">
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">Primary Phone</label>
                                    <input type="text" name="settings[company_phone]" class="form-control" value="<?= htmlspecialchars($settings['company']['company_phone'] ?? '') ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">WhatsApp Number</label>
                                    <input type="text" name="settings[company_whatsapp]" class="form-control" value="<?= htmlspecialchars($settings['company']['company_whatsapp'] ?? '') ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Street Address</label>
                                <input type="text" name="settings[company_address]" class="form-control" value="<?= htmlspecialchars($settings['company']['company_address'] ?? '') ?>">
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">City</label>
                                    <input type="text" name="settings[company_city]" class="form-control" value="<?= htmlspecialchars($settings['company']['company_city'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">State / Province</label>
                                    <input type="text" name="settings[company_state]" class="form-control" value="<?= htmlspecialchars($settings['company']['company_state'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">Postal Code</label>
                                    <input type="text" name="settings[company_zip]" class="form-control" value="<?= htmlspecialchars($settings['company']['company_zip'] ?? '') ?>">
                                </div>
                            </div>
                            <div class="mb-0">
                                <label class="form-label fw-bold">Founding Date</label>
                                <input type="date" name="settings[company_founding_date]" class="form-control w-auto" value="<?= htmlspecialchars($settings['company']['company_founding_date'] ?? '') ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Contact & APIs -->
                <div class="tab-pane fade" id="contact">
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-header bg-white fw-bold py-3"><i class="bi bi-envelope-at me-2 text-primary"></i> SMTP Mailer & External APIs</div>
                        <div class="card-body">
                            <h6 class="fw-bold mb-3 border-bottom pb-2">SMTP Mail Configuration</h6>
                            <div class="row mb-3">
                                <div class="col-md-8">
                                    <label class="form-label fw-bold">SMTP Host</label>
                                    <input type="text" name="settings[smtp_host]" class="form-control" value="<?= htmlspecialchars($settings['contact']['smtp_host'] ?? '') ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-bold">SMTP Port</label>
                                    <input type="text" name="settings[smtp_port]" class="form-control" value="<?= htmlspecialchars($settings['contact']['smtp_port'] ?? '587') ?>">
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">SMTP Username</label>
                                    <input type="text" name="settings[smtp_username]" class="form-control" value="<?= htmlspecialchars($settings['contact']['smtp_username'] ?? '') ?>" autocomplete="off">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-bold">SMTP Password</label>
                                    <input type="password" name="settings[smtp_password]" class="form-control" value="<?= htmlspecialchars($settings['contact']['smtp_password'] ?? '') ?>" autocomplete="off">
                                </div>
                            </div>

                            <h6 class="fw-bold mb-3 border-bottom pb-2 mt-5">Google API Integrations</h6>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Google Maps API Key</label>
                                <input type="text" name="settings[google_maps_key]" class="form-control" value="<?= htmlspecialchars($settings['contact']['google_maps_key'] ?? '') ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Google Search Console Verification Tag</label>
                                <input type="text" name="settings[google_site_verification]" class="form-control" value="<?= htmlspecialchars($settings['contact']['google_site_verification'] ?? '') ?>" placeholder="<meta name='google-site-verification' content='...' />">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- SEO Core Settings (RankMath Style) -->
                <div class="tab-pane fade" id="seo">
                    <div class="card border-0 shadow-sm mb-4 border-top border-primary border-3">
                        <div class="card-header bg-white fw-bold py-3"><i class="bi bi-search me-2 text-primary"></i> RankMath Framework Modules</div>
                        <div class="card-body pb-0">
                            <p class="text-muted small mb-4">Enable or disable core SEO components. By default, all modules should be enabled for a comprehensive E-E-A-T compliant site.</p>
                            
                            <div class="row g-4 mb-4">
                                <?php 
                                    $seoModules = [
                                        'seo_module_404' => ['404 Monitor', 'Log all 404 hit attempts locally to identify broken links.'],
                                        'seo_module_acf' => ['Advanced Custom Fields', 'Enable schema mapping for custom fields.'],
                                        'seo_module_image_seo' => ['Image SEO', 'Auto-add missing ALT tags based on filenames.'],
                                        'seo_module_instant_indexing' => ['Instant Indexing', 'Ping Google/Bing Indexing API on publish.'],
                                        'seo_module_link_counter' => ['Link Counter', 'Count internal/external links passing juice.'],
                                        'seo_module_local' => ['Local SEO & Knowledge Graph', 'Critical module injecting comprehensive JSON-LD.'],
                                        'seo_module_redirections' => ['Redirections', 'Manage 301/302/410 rules.'],
                                        'seo_module_schema' => ['Rich Snippets (Schema)', 'Inject structured data per content type.'],
                                        'seo_module_sitemap' => ['XML Sitemap', 'Auto-generate and ping dynamically.'],
                                        'seo_module_analytics' => ['Analytics Dashboard', 'Connect GSC/GA4 tracking natively.']
                                    ];
                                ?>
                                <?php foreach($seoModules as $k => $v): ?>
                                    <div class="col-md-6">
                                        <div class="form-check form-switch p-3 border rounded shadow-sm">
                                            <input class="form-check-input ms-0 me-3 mt-1" type="checkbox" role="switch" name="settings[<?= $k ?>]" id="<?= $k ?>" <?= ($settings['seo'][$k] ?? '') === '1' ? 'checked' : '' ?> style="transform: scale(1.3);">
                                            <label class="form-check-label w-100" for="<?= $k ?>">
                                                <div class="fw-bold text-dark"><?= $v[0] ?></div>
                                                <div class="small text-muted mt-1"><?= $v[1] ?></div>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Performance & Cache (WP Rocket Style) -->
                <div class="tab-pane fade" id="performance">
                    <div class="card border-0 shadow-sm mb-4 border-top border-warning border-3">
                        <div class="card-header bg-white fw-bold py-3"><i class="bi bi-lightning-charge me-2 text-warning"></i> Advanced Caching Engine</div>
                        <div class="card-body">
                            <div class="alert alert-warning py-2 mb-4 d-flex align-items-center">
                                <i class="bi bi-exclamation-triangle-fill fs-4 me-3"></i>
                                <div class="small">Modifying these settings will instantly purge the entire cache directory. Test frontend after saving.</div>
                            </div>
                            
                            <div class="list-group mb-4">
                                <label class="list-group-item d-flex gap-3 px-4 py-3 bg-light">
                                    <input class="form-check-input flex-shrink-0 fs-4" type="checkbox" name="settings[cache_enabled]" <?= ($settings['performance']['cache_enabled'] ?? '') === '1' ? 'checked' : '' ?>>
                                    <span class="pt-1 form-checked-content">
                                        <strong class="d-block mb-1 fs-5">Enable Core Page Caching</strong>
                                        <span class="text-muted small d-block">Deliver pre-rendered static HTML rather than connecting to the database on every request. Drastically improves TTFB.</span>
                                    </span>
                                </label>
                            </div>

                            <h6 class="fw-bold mb-3">File Optimization</h6>
                            <div class="row g-3 mb-4">
                                <div class="col-md-4">
                                    <div class="form-check p-3 border rounded">
                                        <input class="form-check-input mx-2" type="checkbox" name="settings[cache_minify_html]" id="minHtml" <?= ($settings['performance']['cache_minify_html'] ?? '') === '1' ? 'checked' : '' ?>>
                                        <label class="form-check-label fw-bold" for="minHtml">Minify HTML</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check p-3 border rounded">
                                        <input class="form-check-input mx-2" type="checkbox" name="settings[cache_minify_css]" id="minCss" <?= ($settings['performance']['cache_minify_css'] ?? '') === '1' ? 'checked' : '' ?>>
                                        <label class="form-check-label fw-bold" for="minCss">Minify CSS</label>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-check p-3 border rounded">
                                        <input class="form-check-input mx-2" type="checkbox" name="settings[cache_minify_js]" id="minJs" <?= ($settings['performance']['cache_minify_js'] ?? '') === '1' ? 'checked' : '' ?>>
                                        <label class="form-check-label fw-bold" for="minJs">Minify JS</label>
                                    </div>
                                </div>
                            </div>

                            <h6 class="fw-bold mb-3 mt-4">Media Optimization</h6>
                            <div class="card card-body bg-light border-0">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="settings[image_auto_optimize]" id="imgOpt" <?= ($settings['performance']['image_auto_optimize'] ?? '') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="imgOpt">Lazy Load Images</label>
                                    <div class="form-text mt-0">Add loading="lazy" to content images automatically.</div>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="settings[image_convert_to_webp]" id="imgWebp" <?= ($settings['performance']['image_convert_to_webp'] ?? '') === '1' ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold" for="imgWebp">WebP Conversion</label>
                                    <div class="form-text mt-0">Automatically serve uploaded PNG/JPG as WebP if browser supports it.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sticky Save Footer -->
            <div class="bg-white p-3 border rounded shadow-sm d-flex justify-content-between align-items-center mb-5 position-sticky border-top border-primary border-4" style="bottom: 0; z-index: 100;">
                <div>
                    <span class="fw-bold me-3">Currently Editing:</span>
                    <span id="activeGroupLabel" class="badge bg-primary px-3 py-2 text-uppercase letter-spacing">General</span>
                </div>
                <div>
                    <button class="btn btn-outline-danger me-2" type="button" onclick="if(confirm('Clear all system caches manually?')) { window.location.href='/admin/system/clear-cache'; }"><i class="bi bi-trash"></i> Empty Cache</button>
                    <button type="submit" class="btn btn-primary px-4 fw-bold shadow-sm"><i class="bi bi-save me-2"></i> Save Changes</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.querySelectorAll('.list-group-item').forEach(item => {
        item.addEventListener('click', function() {
            let targetId = this.getAttribute('href').replace('#', '');
            document.getElementById('activeGroup').value = targetId;
            document.getElementById('activeGroupLabel').textContent = targetId;
        });
    });

    // Check URL params for active tab
    const urlParams = new URLSearchParams(window.location.search);
    const activeGroup = urlParams.get('group');
    if (activeGroup) {
        let triggerEl = document.querySelector(`.list-group-item[href="#${activeGroup}"]`);
        if (triggerEl) {
            triggerEl.click();
            let tab = new bootstrap.Tab(triggerEl);
            tab.show();
        }
    }
</script>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
