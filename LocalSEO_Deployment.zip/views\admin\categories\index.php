<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-tags me-2 text-primary"></i> <?= $pageTitle ?></h2>
</div>

<div class="row g-4">
    <!-- Left Col: Add New Category Form -->
    <div class="col-md-4">
        <form method="POST" action="/admin/categories/save" class="card border-0 shadow-sm position-sticky" style="top: 2rem;">
            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
            <input type="hidden" name="id" id="cat_id" value="0">
            
            <div class="card-header bg-white fw-bold py-3" id="formHeader">Add New Category</div>
            <div class="card-body bg-light">
                <div class="mb-3">
                    <label class="form-label fw-bold small">Category Name</label>
                    <input type="text" name="name" id="cat_name" class="form-control" required>
                    <div class="form-text">The name is how it appears on your site.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">Parent Category</label>
                    <select name="parent_id" id="cat_parent" class="form-select">
                        <option value="0">None</option>
                        <?php foreach($flatCategories as $fc): ?>
                            <option value="<?= $fc['id'] ?>"><?= str_repeat('&mdash; ', $fc['level']) . htmlspecialchars($fc['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold small">Description (Optional)</label>
                    <textarea name="description" id="cat_desc" class="form-control" rows="3"></textarea>
                    <div class="form-text">Used on category archive pages.</div>
                </div>

                <hr>
                
                <h6 class="fw-bold small text-muted text-uppercase mb-3">SEO Integration</h6>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Focus Keyword</label>
                    <input type="text" name="focus_keyword" id="cat_focus" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">SEO Meta Title</label>
                    <input type="text" name="seo_title" id="cat_seo_title" class="form-control">
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold small">Meta Description</label>
                    <textarea name="meta_description" id="cat_meta_desc" class="form-control" rows="2"></textarea>
                </div>

                <button type="submit" class="btn btn-primary w-100 fw-bold shadow-sm" id="btnSubmit">Add Category</button>
                <button type="button" class="btn btn-outline-secondary w-100 mt-2 d-none" id="btnCancelEdit" onclick="resetForm()">Cancel Editing</button>
            </div>
        </form>
    </div>

    <!-- Right Col: Category List -->
    <div class="col-md-8">
        <div class="card bg-white shadow-sm border-0 mb-4">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Slug</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(empty($flatCategories)): ?>
                            <tr><td colspan="4" class="text-center py-5 text-muted">No categories created yet.</td></tr>
                        <?php else: ?>
                            <?php foreach($flatCategories as $cat): ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold text-dark">
                                            <?php echo str_repeat('&mdash; ', $cat['level']); ?>
                                            <?= htmlspecialchars($cat['name']) ?>
                                        </div>
                                    </td>
                                    <td class="small text-muted"><?= htmlspecialchars(substr($cat['description'] ?? '', 0, 50)) ?><?= strlen($cat['description'] ?? '') > 50 ? '...' : '' ?></td>
                                    <td><code class="text-dark bg-light px-2 py-1 rounded"><?= htmlspecialchars($cat['slug']) ?></code></td>
                                    <td class="text-end">
                                        <button type="button" class="btn btn-sm btn-outline-primary me-2" onclick='editCategory(<?= json_encode($cat) ?>)'>Edit</button>
                                        <form action="/admin/categories/delete/<?= $cat['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this category? Posts assigned to it will not be deleted.');">
                                            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function editCategory(data) {
    document.getElementById('formHeader').innerText = 'Edit Category';
    document.getElementById('btnSubmit').innerText = 'Update Category';
    document.getElementById('btnCancelEdit').classList.remove('d-none');
    
    document.getElementById('cat_id').value = data.id;
    document.getElementById('cat_name').value = data.name;
    document.getElementById('cat_parent').value = data.parent_id;
    document.getElementById('cat_desc').value = data.description;
    
    document.getElementById('cat_focus').value = data.focus_keyword || '';
    document.getElementById('cat_seo_title').value = data.seo_title || '';
    document.getElementById('cat_meta_desc').value = data.meta_description || '';

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
    document.getElementById('formHeader').innerText = 'Add New Category';
    document.getElementById('btnSubmit').innerText = 'Add Category';
    document.getElementById('btnCancelEdit').classList.add('d-none');
    
    document.getElementById('cat_id').value = '0';
    document.getElementById('cat_name').value = '';
    document.getElementById('cat_parent').value = '0';
    document.getElementById('cat_desc').value = '';
    
    document.getElementById('cat_focus').value = '';
    document.getElementById('cat_seo_title').value = '';
    document.getElementById('cat_meta_desc').value = '';
}
</script>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
