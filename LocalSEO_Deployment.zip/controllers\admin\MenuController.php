<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Setting;

class MenuController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin']);
        
        $settingModel = new Setting();
        
        $menus = [
            'primary' => json_decode($settingModel->first("setting_key = 'menu_primary'")['setting_value'] ?? '[]', true),
            'footer' => json_decode($settingModel->first("setting_key = 'menu_footer'")['setting_value'] ?? '[]', true)
        ];

        // Fetch pages and categories to allow user to add them easily
        $db = \Core\Database::getInstance();
        $pages = $db->fetchAll("SELECT id, title, slug FROM {$db->t('pages')} WHERE status='published' ORDER BY title ASC");
        $categories = $db->fetchAll("SELECT id, name, slug FROM {$db->t('categories')} ORDER BY name ASC");

        $this->adminView('menus/index', [
            'pageTitle' => 'Menus Management',
            'menus' => $menus,
            'pages' => $pages,
            'categories' => $categories
        ]);
    }

    public function save() {
        $this->requireRole(['super_admin', 'admin']);
        $this->verifyCsrf();

        $menuType = $this->input('menu_type', 'primary');
        if (!in_array($menuType, ['primary', 'footer'])) $menuType = 'primary';
        
        $menuData = $this->input('menu_data', '[]');
        
        $settingModel = new Setting();
        $settingModel->set('menu_' . $menuType, $menuData, 'theme', true);

        // Clear cache
        $cm = new \Core\CacheMonitor();
        $cm->clearType('objects');

        Helpers::flash('success', ucfirst($menuType) . ' menu saved successfully.');
        $this->redirect('/admin/menus');
    }
}
