<?php
namespace Models;
use Core\Model;

class Menu extends Model {
    protected $table = 'menus';
    protected $fillable = ['name', 'location', 'status'];

    public function getItems() {
        return $this->db->fetchAll("SELECT * FROM {$this->prefix}menu_items WHERE menu_id = ? ORDER BY order_index ASC", [$this->id]);
    }
}
