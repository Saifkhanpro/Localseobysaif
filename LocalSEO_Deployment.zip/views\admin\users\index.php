<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-people me-2 text-primary"></i> <?= $pageTitle ?></h2>
    <a href="/admin/users/create" class="btn btn-primary"><i class="bi bi-person-plus"></i> Add New User</a>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th style="width: 50px;">Avatar</th>
                    <th>User & Email</th>
                    <th>Role</th>
                    <th>SEO Access</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($users)): ?>
                    <tr><td colspan="6" class="text-center py-5 text-muted">No users found.</td></tr>
                <?php else: ?>
                    <?php foreach($users as $user): ?>
                        <tr>
                            <td>
                                <img src="https://www.gravatar.com/avatar/<?= md5(strtolower(trim($user['email']))) ?>?s=80&d=mp" class="rounded-circle shadow-sm" width="40" height="40" alt="Avatar">
                            </td>
                            <td>
                                <div class="fw-bold mb-1"><a href="/admin/users/edit/<?= $user['id'] ?>" class="text-dark text-decoration-none"><?= htmlspecialchars($user['display_name']) ?></a></div>
                                <div class="small text-muted"><?= htmlspecialchars($user['email']) ?></div>
                            </td>
                            <td>
                                <?php 
                                    $roles = ['super_admin' => 'danger', 'admin' => 'primary', 'editor' => 'info', 'subscriber' => 'secondary'];
                                    $col = $roles[$user['role']] ?? 'secondary';
                                    $label = ucwords(str_replace('_', ' ', $user['role']));
                                ?>
                                <span class="badge bg-<?= $col ?> bg-opacity-10 text-<?= $col ?> border border-<?= $col ?>"><?= $label ?></span>
                            </td>
                            <td>
                                <?php if($user['seo_role'] === 'seo_manager'): ?>
                                    <span class="badge bg-success"><i class="bi bi-search"></i> SEO Manager</span>
                                <?php else: ?>
                                    <span class="text-muted small">None</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user['is_active']): ?>
                                    <span class="text-success small fw-bold"><i class="bi bi-circle-fill fs-6 me-1"></i> Active</span>
                                <?php else: ?>
                                    <span class="text-danger small fw-bold"><i class="bi bi-dash-circle-fill fs-6 me-1"></i> Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="/admin/users/edit/<?= $user['id'] ?>" class="btn btn-sm btn-outline-primary me-2"><i class="bi bi-pencil"></i></a>
                                <?php if($user['id'] != $this->auth->user()['id']): ?>
                                    <form action="/admin/users/delete/<?= $user['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('WARNING: This completely deletes the user. Are you absolutely certain?');">
                                        <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
