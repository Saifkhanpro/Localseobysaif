<?php
namespace Controllers\Admin;
use Core\Controller;
class SitemapController extends Controller {
    public function __call($name, $arguments) {
        $this->requireAuth();
        echo "<h1>Under Construction</h1><p>Sitemap admin module ($name) is being built.</p>";
    }
}
