<?php
namespace Core;

class Validator {
    private $errors = [];

    public function validate(array $data, array $rules): array {
        $this->errors = [];
        foreach ($rules as $field => $ruleSet) {
            $ruleList = is_array($ruleSet) ? $ruleSet : explode('|', $ruleSet);
            $value = $data[$field] ?? null;
            $label = ucfirst(str_replace('_', ' ', $field));

            foreach ($ruleList as $rule) {
                $params = [];
                if (strpos($rule, ':') !== false) {
                    list($rule, $paramStr) = explode(':', $rule, 2);
                    $params = explode(',', $paramStr);
                }
                switch ($rule) {
                    case 'required':
                        if ($value === null || $value === '') $this->errors[$field] = "{$label} is required.";
                        break;
                    case 'email':
                        if ($value && !filter_var($value, FILTER_VALIDATE_EMAIL)) $this->errors[$field] = "{$label} must be valid email.";
                        break;
                    case 'min':
                        if ($value && mb_strlen($value) < (int)$params[0]) $this->errors[$field] = "{$label} must be at least {$params[0]} characters.";
                        break;
                    case 'max':
                        if ($value && mb_strlen($value) > (int)$params[0]) $this->errors[$field] = "{$label} must not exceed {$params[0]} characters.";
                        break;
                    case 'numeric':
                        if ($value && !is_numeric($value)) $this->errors[$field] = "{$label} must be numeric.";
                        break;
                    case 'url':
                        if ($value && !filter_var($value, FILTER_VALIDATE_URL)) $this->errors[$field] = "{$label} must be a valid URL.";
                        break;
                    case 'slug':
                        if ($value && !preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $value)) $this->errors[$field] = "{$label} must be a valid slug.";
                        break;
                    case 'alpha':
                        if ($value && !ctype_alpha($value)) $this->errors[$field] = "{$label} must only contain letters.";
                        break;
                    case 'alphanumeric':
                        if ($value && !ctype_alnum($value)) $this->errors[$field] = "{$label} must be alphanumeric.";
                        break;
                    case 'in':
                        if ($value && !in_array($value, $params)) $this->errors[$field] = "{$label} is invalid.";
                        break;
                    case 'unique':
                        if ($value && count($params) >= 2) {
                            $db = Database::getInstance();
                            $table = $db->t($params[0]);
                            $col = $params[1];
                            $excludeId = $params[2] ?? null;
                            $sql = "SELECT COUNT(*) FROM {$table} WHERE {$col} = ?";
                            $p = [$value];
                            if ($excludeId) { $sql .= " AND id != ?"; $p[] = $excludeId; }
                            if ($db->fetchColumn($sql, $p) > 0) $this->errors[$field] = "{$label} already exists.";
                        }
                        break;
                    case 'match':
                        if ($value !== ($data[$params[0]] ?? null)) $this->errors[$field] = "{$label} does not match.";
                        break;
                    case 'phone':
                        if ($value && !preg_match('/^[\+]?[0-9\s\-\(\)]{7,20}$/', $value)) $this->errors[$field] = "{$label} is not a valid phone number.";
                        break;
                }
                if (isset($this->errors[$field])) break;
            }
        }
        return $this->errors;
    }

    public function hasErrors(): bool { return !empty($this->errors); }
    public function getErrors(): array { return $this->errors; }
    public function getError(string $field): ?string { return $this->errors[$field] ?? null; }
}
