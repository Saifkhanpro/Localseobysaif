<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><i class="bi bi-arrow-left-right me-2 text-primary"></i> <?= $pageTitle ?></h2>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#redirectModal">
        <i class="bi bi-plus-lg"></i> Add New Redirect
    </button>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="card-body py-3 bg-light rounded-top text-muted small">
        <strong>Overview:</strong> Managing 301 (Permanent) and 302 (Temporary) redirects directly impacts indexing status. Ensure you migrate link equity properly.
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr>
                    <th>Old URL (Source)</th>
                    <th>New URL (Target)</th>
                    <th>Type</th>
                    <th>Match Logic</th>
                    <th>Hits</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if(empty($redirects)): ?>
                    <tr><td colspan="6" class="text-center py-5 text-muted">No redirects configured.</td></tr>
                <?php else: ?>
                    <?php foreach($redirects as $r): ?>
                        <tr>
                            <td><code class="text-dark bg-light px-2 py-1 rounded"><?= htmlspecialchars($r['old_url']) ?></code></td>
                            <td><code class="text-primary bg-light px-2 py-1 rounded"><?= htmlspecialchars($r['new_url']) ?></code></td>
                            <td>
                                <?php if($r['type'] == 301): ?>
                                    <span class="badge bg-success">301 Permanent</span>
                                <?php elseif($r['type'] == 302): ?>
                                    <span class="badge bg-warning text-dark">302 Temporary</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><?= $r['type'] ?> Gone</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge bg-secondary bg-opacity-25 text-dark fw-normal"><?= ucfirst($r['match_type']) ?></span></td>
                            <td><span class="badge bg-light text-dark border"><?= number_format($r['hits']) ?></span></td>
                            <td class="text-end">
                                <form action="/admin/seo/redirects/delete/<?= $r['id'] ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this redirect rule?');">
                                    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="redirectModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="/admin/seo/redirects/save">
          <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
          <div class="modal-header">
            <h5 class="modal-title fw-bold">Add Redirection Rule</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
                <label class="form-label fw-bold small">Source URL</label>
                <input type="text" name="old_url" class="form-control" required placeholder="/old-page-url">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold small">Destination URL</label>
                <input type="text" name="new_url" class="form-control" required placeholder="/new-page-url">
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold small">Redirect Type</label>
                    <select name="type" class="form-select">
                        <option value="301">301 (Permanent Move)</option>
                        <option value="302">302 (Temporary Move)</option>
                        <option value="410">410 (Content Deleted)</option>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold small">Match Type</label>
                    <select name="match_type" class="form-select">
                        <option value="exact">Exact Match</option>
                        <option value="contains">Contains Word</option>
                        <option value="startswith">Starts With</option>
                        <option value="regex">Regex pattern</option>
                    </select>
                </div>
            </div>
            <div class="form-check form-switch mt-2">
                <input class="form-check-input" type="checkbox" name="is_active" value="1" checked id="isActive">
                <label class="form-check-label fw-bold small" for="isActive">Activate Rule Immediately</label>
            </div>
          </div>
          <div class="modal-footer bg-light">
            <button type="submit" class="btn btn-primary w-100 fw-bold">Save Redirect</button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
