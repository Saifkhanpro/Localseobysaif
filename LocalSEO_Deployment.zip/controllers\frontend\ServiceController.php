<?php
namespace Controllers\Frontend;
use Core\Controller;
use Models\Service;

class ServiceController extends Controller {
    public function index() {
        $serviceModel = new Service();
        $services = $serviceModel->where("status = 'published'", [], "order_index ASC");

        $data = [
            'services' => $services,
            'pageTitle' => 'Our Local SEO Services | ' . $this->setting('site_name', 'LocalSEO.pk'),
            'metaDescription' => 'Explore our comprehensive local SEO services designed to help Pakistani businesses dominate local search results.',
            'canonicalUrl' => APP_URL . '/services'
        ];

        $this->frontendView('services/index', $data);
    }

    public function show(string $slug) {
        $serviceModel = new Service();
        $service = $serviceModel->findBySlug($slug);

        if (!$service || $service['status'] !== 'published') {
            http_response_code(404);
            $this->frontendView('404', ['pageTitle' => 'Service Not Found']);
            return;
        }

        $data = [
            'service' => $service,
            'pageTitle' => $service['seo_title'] ?: $service['title'] . ' Services',
            'metaDescription' => $service['meta_description'] ?: $service['short_description'],
            'canonicalUrl' => $service['canonical_url'] ?: APP_URL . '/services/' . $service['slug'],
            'schema' => json_decode($service['schema_data'] ?? '[]', true),
            'robots' => []
        ];

        if ($service['robots_index'] === 'noindex') $data['robots'][] = 'noindex';
        if ($service['robots_follow'] === 'nofollow') $data['robots'][] = 'nofollow';

        $this->frontendView('services/single', $data);
    }
}
