<?php
namespace Models;
use Core\Model;

class Service extends Model {
    protected $table = 'services';
    protected $fillable = [
        'title', 'slug', 'short_description', 'content', 'icon_class',
        'featured_image_id', 'status', 'order_index', 'price_range',
        'focus_keyword', 'secondary_keywords', 'seo_title', 'meta_description',
        'robots_index', 'robots_follow', 'robots_advanced', 'canonical_url',
        'readability_score', 'seo_score', 'schema_type', 'schema_data',
        'published_at'
    ];
}
