<?php
namespace Models;
use Core\Model;

class Category extends Model {
    protected $table = 'categories';
    protected $fillable = [
        'name', 'slug', 'description', 'parent_id', 'seo_title', 'meta_description',
        'focus_keyword', 'robots_index', 'robots_follow', 'canonical_url', 'order_index'
    ];

    public function getTree(int $parentId = null): array {
        $sql = "SELECT c.*, (SELECT COUNT(*) FROM {$this->db->t('post_categories')} pc JOIN {$this->db->t('posts')} p ON pc.post_id = p.id WHERE pc.category_id = c.id AND p.status='published') as post_count 
                FROM {$this->table} c";
        $params = [];
        if ($parentId !== null) {
            $sql .= " WHERE c.parent_id = ?";
            $params[] = $parentId;
        } else {
            $sql .= " WHERE c.parent_id IS NULL";
        }
        $sql .= " ORDER BY c.order_index ASC, c.name ASC";
        
        $categories = $this->db->fetchAll($sql, $params);
        foreach ($categories as &$cat) {
            $cat['children'] = $this->getTree($cat['id']);
        }
        return $categories;
    }
    
    public function getIdsFlatTree(): array {
        $tree = $this->getTree();
        $flat = [];
        $flatten = function($items, $level = 0) use (&$flatten, &$flat) {
            foreach ($items as $item) {
                $item['level'] = $level;
                $flat[] = $item;
                if (!empty($item['children'])) $flatten($item['children'], $level + 1);
            }
        };
        $flatten($tree);
        return $flat;
    }
}
