<?php
namespace Core;

class CachePreloader {
    public function preload(): array {
        $db = Database::getInstance();
        $prefix = $db->getTablePrefix();
        $cache = new PageCache();
        $urls = ['/'];

        // Published posts
        $posts = $db->fetchAll("SELECT slug FROM {$prefix}posts WHERE status = 'published' ORDER BY published_at DESC LIMIT 50");
        foreach ($posts as $p) $urls[] = '/blog/' . $p['slug'];

        // Services
        $services = $db->fetchAll("SELECT slug FROM {$prefix}services WHERE status = 'published'");
        foreach ($services as $s) $urls[] = '/services/' . $s['slug'];

        // City pages
        $cities = $db->fetchAll("SELECT slug FROM {$prefix}city_pages WHERE status = 'published'");
        foreach ($cities as $c) $urls[] = '/local-seo/' . $c['slug'];

        // Pages
        $pages = $db->fetchAll("SELECT slug FROM {$prefix}pages WHERE status = 'published'");
        foreach ($pages as $p) $urls[] = '/' . $p['slug'];

        return ['total' => count($urls), 'urls' => $urls];
    }
}
