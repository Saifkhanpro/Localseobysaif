<?php ob_start(); ?>

<form method="POST" action="/admin/services/save">
    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
    <input type="hidden" name="id" value="<?= $service['id'] ?? 0 ?>">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save Service</button>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Service Title</label>
                        <input type="text" name="title" class="form-control form-control-lg" required value="<?= htmlspecialchars($service['title'] ?? '') ?>">
                        <?php if(isset($service['slug'])): ?>
                            <div class="form-text mt-2"><i class="bi bi-link-45deg"></i> Permalink: <strong><?= rtrim(APP_URL, '/') ?>/services/<?= htmlspecialchars($service['slug']) ?></strong></div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold">Short Description</label>
                        <textarea name="short_description" class="form-control" rows="3" placeholder="Brief summary for service grids..."><?= htmlspecialchars($service['short_description'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-bold">Full Service Content</label>
                        <textarea name="content" class="wysiwyg form-control"><?= htmlspecialchars($service['content'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4 border-top border-primary border-3">
                <div class="card-header bg-white">
                    <h5 class="mb-0 text-primary"><i class="bi bi-search me-2"></i> SEO Parameters</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Focus Keyword</label>
                        <input type="text" name="focus_keyword" class="form-control" value="<?= htmlspecialchars($service['focus_keyword'] ?? '') ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">SEO Title</label>
                        <input type="text" name="seo_title" class="form-control" value="<?= htmlspecialchars($service['seo_title'] ?? '') ?>">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="3"><?= htmlspecialchars($service['meta_description'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Publishing & Meta</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Status</label>
                        <select name="status" class="form-select">
                            <option value="draft" <?= ($service['status'] ?? 'draft') === 'draft' ? 'selected' : '' ?>>Draft</option>
                            <option value="published" <?= ($service['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Icon Class</label>
                        <input type="text" name="icon_class" class="form-control" placeholder="e.g. bi bi-rocket" value="<?= htmlspecialchars($service['icon_class'] ?? '') ?>">
                        <div class="form-text small">Bootstrap icon class for grids.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Price Range String</label>
                        <input type="text" name="price_range" class="form-control" placeholder="e.g. $500 - $1,500" value="<?= htmlspecialchars($service['price_range'] ?? '') ?>">
                        <div class="form-text small">Used for Schema.org rendering.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Menu Order</label>
                        <input type="number" name="order_index" class="form-control" value="<?= $service['order_index'] ?? 0 ?>">
                    </div>
                </div>
                <div class="card-footer bg-light text-end">
                    <button type="submit" class="btn btn-primary w-100">Save Service</button>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold">Service Image</div>
                <div class="card-body text-center">
                    <input type="hidden" name="featured_image_id" id="featured_image_id" value="<?= $service['featured_image_id'] ?? '' ?>">
                    <div id="image-preview" class="mb-3 <?= empty($featuredImageUrl) ? 'd-none' : '' ?>">
                        <img src="<?= htmlspecialchars($featuredImageUrl ?? '') ?>" class="img-fluid rounded border">
                    </div>
                    <button type="button" class="btn btn-outline-secondary w-100" onclick="alert('Media Selection');"><i class="bi bi-image"></i> Set Image</button>
                </div>
            </div>
        </div>
    </div>
</form>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
