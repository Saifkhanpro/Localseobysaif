<?php ob_start(); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
    <a href="/admin/posts/create" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Add New</a>
</div>

<div class="card bg-white shadow-sm border-0 mb-4">
    <div class="card-body py-3 d-flex justify-content-between align-items-center bg-light rounded-top">
        <div class="d-flex gap-3 text-muted small">
            <a href="/admin/posts" class="text-decoration-none <?= !isset($_GET['status']) ? 'text-dark fw-bold' : 'text-muted' ?>">All (<?= $counts['all'] ?>)</a> | 
            <a href="/admin/posts?status=published" class="text-decoration-none <?= ($_GET['status'] ?? '') === 'published' ? 'text-dark fw-bold' : 'text-muted' ?>">Published (<?= $counts['published'] ?>)</a> | 
            <a href="/admin/posts?status=draft" class="text-decoration-none <?= ($_GET['status'] ?? '') === 'draft' ? 'text-dark fw-bold' : 'text-muted' ?>">Drafts (<?= $counts['draft'] ?>)</a> | 
            <a href="/admin/posts?status=trash" class="text-decoration-none text-danger <?= ($_GET['status'] ?? '') === 'trash' ? 'fw-bold' : '' ?>">Trash (<?= $counts['trash'] ?>)</a>
        </div>
        
        <form method="GET" action="/admin/posts" class="d-flex">
            <?php if(isset($_GET['status'])): ?><input type="hidden" name="status" value="<?= htmlspecialchars($_GET['status']) ?>"><?php endif; ?>
            <div class="input-group input-group-sm">
                <input type="text" name="s" class="form-control" placeholder="Search posts..." value="<?= htmlspecialchars($_GET['s'] ?? '') ?>">
                <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
            </div>
        </form>
    </div>

    <form method="POST" action="/admin/posts/action" id="bulk-form">
        <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
        <div class="card-body border-bottom d-flex gap-2 py-2">
            <select name="action" class="form-select form-select-sm w-auto" required>
                <option value="">Bulk Actions</option>
                <?php if(($_GET['status'] ?? '') === 'trash'): ?>
                    <option value="restore">Restore</option>
                    <option value="delete">Delete Permanently</option>
                <?php else: ?>
                    <option value="trash">Move to Trash</option>
                <?php endif; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Are you sure you want to apply this bulk action?');">Apply</button>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 40px;"><input type="checkbox" class="form-check-input" id="selectAll"></th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>SEO Score</th>
                        <th>Readability</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($posts)): ?>
                        <tr><td colspan="6" class="text-center py-5 text-muted">No posts found.</td></tr>
                    <?php else: ?>
                        <?php foreach($posts as $post): ?>
                            <tr>
                                <td><input type="checkbox" name="ids[]" value="<?= $post['id'] ?>" class="form-check-input row-chk"></td>
                                <td>
                                    <div class="fw-bold mb-1">
                                        <?= htmlspecialchars($post['title']) ?>
                                        <?php if($post['status'] !== 'published'): ?>
                                            <span class="badge bg-secondary ms-1"><?= ucfirst($post['status']) ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="small">
                                        <?php if(($_GET['status'] ?? '') === 'trash'): ?>
                                            <a href="#" onclick="document.getElementById('single-action-<?= $post['id'] ?>').value='restore'; document.getElementById('single-form-<?= $post['id'] ?>').submit(); return false;" class="text-success text-decoration-none me-2">Restore</a>
                                            <a href="#" onclick="if(confirm('Delete permanently?')) { document.getElementById('single-action-<?= $post['id'] ?>').value='delete'; document.getElementById('single-form-<?= $post['id'] ?>').submit(); } return false;" class="text-danger text-decoration-none">Delete Permanently</a>
                                        <?php else: ?>
                                            <a href="/admin/posts/edit/<?= $post['id'] ?>" class="text-primary text-decoration-none me-2">Edit</a>
                                            <a href="/blog/<?= $post['slug'] ?>" target="_blank" class="text-muted text-decoration-none me-2">View</a>
                                            <a href="#" onclick="document.getElementById('single-action-<?= $post['id'] ?>').value='trash'; document.getElementById('single-form-<?= $post['id'] ?>').submit(); return false;" class="text-danger text-decoration-none">Trash</a>
                                        <?php endif; ?>
                                        
                                        <form method="POST" action="/admin/posts/action" id="single-form-<?= $post['id'] ?>" class="d-none">
                                            <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
                                            <input type="hidden" name="ids[]" value="<?= $post['id'] ?>">
                                            <input type="hidden" name="action" id="single-action-<?= $post['id'] ?>" value="">
                                        </form>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($post['author'] ?? 'Unknown') ?></td>
                                <td>
                                    <?php 
                                    $s = $post['seo_score'];
                                    $col = $s >= 80 ? 'success' : ($s >= 50 ? 'warning' : 'danger');
                                    ?>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="progress flex-grow-1 border" style="height: 6px; width: 60px;">
                                            <div class="progress-bar bg-<?= $col ?>" style="width: <?= $s ?>%"></div>
                                        </div>
                                        <span class="text-<?= $col ?> fw-bold small"><?= $s ?>/100</span>
                                    </div>
                                </td>
                                <td>
                                    <?php 
                                    $r = $post['readability_score'];
                                    $colR = $r >= 60 ? 'success' : ($r >= 40 ? 'warning' : 'danger');
                                    ?>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="progress flex-grow-1 border" style="height: 6px; width: 60px;">
                                            <div class="progress-bar bg-<?= $colR ?>" style="width: <?= $r ?>%"></div>
                                        </div>
                                        <span class="text-<?= $colR ?> fw-bold small"><?= $r ?>/100</span>
                                    </div>
                                </td>
                                <td class="small">
                                    <?php 
                                    if ($post['status'] === 'published') {
                                        echo 'Published<br>' . date('Y/m/d g:i a', strtotime($post['published_at']));
                                    } else {
                                        echo 'Last Modified<br>' . date('Y/m/d g:i a', strtotime($post['updated_at']));
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </form>
    
    <?php if($pagination['last_page'] > 1): ?>
    <div class="card-footer bg-white py-3">
        <nav>
            <ul class="pagination pagination-sm mb-0 justify-content-end">
                <?php for($i=1; $i<=$pagination['last_page']; $i++): ?>
                    <li class="page-item <?= $i == $pagination['current'] ? 'active' : '' ?>">
                        <a class="page-link" href="?p=<?= $i ?><?= isset($_GET['status']) ? '&status='.htmlspecialchars($_GET['status']) : '' ?><?= isset($_GET['s']) ? '&s='.htmlspecialchars($_GET['s']) : '' ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
    <?php endif; ?>
</div>

<script>
    document.getElementById('selectAll').addEventListener('change', function(e) {
        document.querySelectorAll('.row-chk').forEach(chk => chk.checked = e.target.checked);
    });
</script>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
