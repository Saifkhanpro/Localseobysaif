<?php
namespace Core;

class Cache {
    protected $cachePath;
    protected $enabled;

    public function __construct(string $subDir = '') {
        $this->cachePath = CACHE_PATH . ($subDir ? '/' . $subDir : '/objects');
        $this->enabled = defined('CACHE_ENABLED') ? CACHE_ENABLED : true;
        if (!is_dir($this->cachePath)) {
            @mkdir($this->cachePath, 0755, true);
        }
    }

    public function get(string $key, $default = null) {
        if (!$this->enabled) return $default;
        $file = $this->getFilePath($key);
        if (!file_exists($file)) return $default;
        $data = @file_get_contents($file);
        if ($data === false) return $default;
        $cache = @unserialize($data);
        if ($cache === false) return $default;
        if ($cache['expires'] > 0 && $cache['expires'] < time()) {
            @unlink($file);
            return $default;
        }
        return $cache['data'];
    }

    public function set(string $key, $data, int $ttl = 3600): bool {
        if (!$this->enabled) return false;
        $file = $this->getFilePath($key);
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $cache = ['data' => $data, 'expires' => $ttl > 0 ? time() + $ttl : 0, 'created' => time()];
        return @file_put_contents($file, serialize($cache), LOCK_EX) !== false;
    }

    public function delete(string $key): bool {
        $file = $this->getFilePath($key);
        return file_exists($file) ? @unlink($file) : true;
    }

    public function has(string $key): bool {
        return $this->get($key) !== null;
    }

    public function clear(): int {
        return $this->clearDirectory($this->cachePath);
    }

    public function clearDirectory(string $dir): int {
        $count = 0;
        if (!is_dir($dir)) return 0;
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($dir, \RecursiveDirectoryIterator::SKIP_DOTS), \RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($files as $file) {
            if ($file->isDir()) {
                @rmdir($file->getRealPath());
            } else {
                if ($file->getFilename() !== '.htaccess') {
                    @unlink($file->getRealPath());
                    $count++;
                }
            }
        }
        return $count;
    }

    public function getSize(): int {
        $size = 0;
        if (!is_dir($this->cachePath)) return 0;
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($this->cachePath));
        foreach ($files as $file) {
            if ($file->isFile()) $size += $file->getSize();
        }
        return $size;
    }

    public function getFileCount(): int {
        if (!is_dir($this->cachePath)) return 0;
        $count = 0;
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($this->cachePath));
        foreach ($files as $file) {
            if ($file->isFile() && $file->getFilename() !== '.htaccess') $count++;
        }
        return $count;
    }

    protected function getFilePath(string $key): string {
        $hash = md5($key);
        $subDir = substr($hash, 0, 2);
        return $this->cachePath . '/' . $subDir . '/' . $hash . '.cache';
    }
}
