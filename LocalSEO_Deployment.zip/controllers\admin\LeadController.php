<?php
namespace Controllers\Admin;
use Core\Controller;
use Core\Helpers;
use Models\Lead;

class LeadController extends Controller {
    public function index() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $leadModel = new Lead();
        $page = (int)$this->input('p', 1);
        $perPage = 20;

        $s = $this->input('s');
        $status = $this->input('status');
        
        $where = "1=1";
        $params = [];
        
        if ($s) {
            $where .= " AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ?)";
            $params[] = "%{$s}%";
            $params[] = "%{$s}%";
            $params[] = "%{$s}%";
        }
        
        if ($status && in_array($status, ['new', 'contacted', 'qualified', 'converted', 'closed'])) {
            $where .= " AND status = ?";
            $params[] = $status;
        }

        $paginated = $leadModel->paginate($page, $perPage, $where, $params, 'created_at DESC');

        $this->adminView('leads/index', [
            'pageTitle' => 'Leads Management',
            'leads' => $paginated['items'],
            'pagination' => $paginated,
            'counts' => [
                'all' => $leadModel->count(),
                'new' => $leadModel->count("status='new'"),
                'unread' => $leadModel->getUnreadCount()
            ]
        ]);
    }

    public function show(int $id) {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        
        $leadModel = new Lead();
        $lead = $leadModel->find($id);

        if (!$lead) {
            Helpers::flash('error', 'Lead not found.');
            $this->redirect('/admin/leads');
            return;
        }

        // Mark as read when viewing
        if ($lead['is_read'] == 0) {
            $leadModel->markRead($id);
            $lead['is_read'] = 1;
        }

        // Available users for assignment
        $db = \Core\Database::getInstance();
        $users = $db->fetchAll("SELECT id, display_name FROM {$db->t('users')} WHERE is_active = 1 AND role IN ('super_admin', 'admin', 'editor')");

        $assignedUser = null;
        if ($lead['assigned_to']) {
            $assignedUser = $db->fetchColumn("SELECT display_name FROM {$db->t('users')} WHERE id = ?", [$lead['assigned_to']]);
        }

        $this->adminView('leads/show', [
            'pageTitle' => 'Lead Details: ' . $lead['full_name'],
            'lead' => $lead,
            'users' => $users,
            'assignedUser' => $assignedUser
        ]);
    }

    public function update() {
        $this->requireRole(['super_admin', 'admin', 'editor']);
        $this->verifyCsrf();

        $id = (int)$this->input('id', 0);
        $leadModel = new Lead();
        $lead = $leadModel->find($id);

        if (!$lead) {
            $this->redirect('/admin/leads');
            return;
        }

        $status = $this->input('status');
        $notes = $this->input('notes');
        $assignedTo = (int)$this->input('assigned_to');
        if ($assignedTo === 0) $assignedTo = null;

        $leadModel->update($id, [
            'status' => in_array($status, ['new', 'contacted', 'qualified', 'converted', 'closed']) ? $status : 'new',
            'notes' => $notes,
            'assigned_to' => $assignedTo
        ]);

        $this->security->logActivity('update_lead', $this->auth->user()['id'], 'lead', $id, "Updated lead status for: {$lead['full_name']}");
        Helpers::flash('success', 'Lead updated successfully.');
        $this->redirect('/admin/leads/' . $id);
    }

    public function export() {
        $this->requireRole(['super_admin', 'admin']);
        
        $status = $this->input('status');
        $sql = "SELECT full_name, email, phone, whatsapp_number, city, service_needed, status, created_at, source_url, utm_medium, notes FROM " . \Core\Database::getInstance()->t('leads');
        $params = [];
        
        if ($status && in_array($status, ['new', 'contacted', 'qualified', 'converted', 'closed'])) {
            $sql .= " WHERE status = ?";
            $params[] = $status;
        }
        $sql .= " ORDER BY created_at DESC";

        $headers = ['Full Name', 'Email', 'Phone', 'WhatsApp', 'City', 'Service Needed', 'Status', 'Date Submitted', 'Source URL', 'UTM Medium', 'Admin Notes'];
        
        \Core\CSVExporter::queryToCsv($sql, $params, $headers, 'leads-export-' . date('Y-m-d'));
    }

    public function deleteAction() {
        $this->requireRole(['super_admin', 'admin']);
        $this->verifyCsrf();
        
        $action = $this->input('action');
        $ids = (array)$this->input('ids', []);

        if ($action === 'delete' && !empty($ids)) {
            $leadModel = new Lead();
            $count = 0;
            foreach ($ids as $id) {
                if ($leadModel->delete((int)$id)) $count++;
            }
            Helpers::flash('success', "Deleted {$count} leads successfully.");
            $this->security->logActivity('delete_leads', $this->auth->user()['id'], 'lead', null, "Deleted {$count} leads physically");
        }
        
        $this->redirect('/admin/leads');
    }
}
