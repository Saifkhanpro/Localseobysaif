<?php
namespace Controllers\Frontend;
use Core\Controller;
class CommentController extends Controller {
    public function store() {
        // Mock processing
        \Core\Helpers::flash('success', 'Comment submitted for moderation.');
        $this->redirect($_SERVER['HTTP_REFERER'] ?? '/');
    }
}
