<?php ob_start(); ?>

<form method="POST" action="/admin/users/save">
    <input type="hidden" name="csrf_token" value="<?= \Core\CSRF::generate() ?>">
    <input type="hidden" name="id" value="<?= $user['id'] ?? 0 ?>">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 mb-0"><?= $pageTitle ?></h2>
        <button type="submit" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save User</button>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold py-3"><i class="bi bi-person-badge me-2 text-primary"></i> Account Details</div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Username</label>
                            <input type="text" name="username" class="form-control bg-light" required value="<?= htmlspecialchars($user['username'] ?? '') ?>" <?= ($user['id'] ?? 0) > 0 ? 'readonly' : '' ?>>
                            <div class="form-text">Used for login. Cannot be changed after creation.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Email Address</label>
                            <input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($user['email'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">First Name</label>
                            <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($user['first_name'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($user['last_name'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Display Name Default</label>
                            <input type="text" name="display_name" class="form-control" required value="<?= htmlspecialchars($user['display_name'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Bio (Author Archive)</label>
                        <textarea name="bio" class="form-control" rows="4"><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-0">
                        <label class="form-label fw-bold">Website / Social URL</label>
                        <input type="url" name="website" class="form-control" value="<?= htmlspecialchars($user['website'] ?? '') ?>">
                    </div>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4 border-top border-warning border-3">
                <div class="card-header bg-white fw-bold py-3"><i class="bi bi-key me-2 text-warning"></i> Password Management</div>
                <div class="card-body">
                    <div class="alert alert-info py-2 small mb-3">
                        <i class="bi bi-info-circle me-2"></i> Leave blank if you don't wish to change the existing password. Note that changing a password will immediately terminate all active sessions for this user.
                    </div>
                    <div class="mb-0">
                        <label class="form-label fw-bold">New Password</label>
                        <input type="password" name="password" class="form-control" <?= ($user['id'] ?? 0) == 0 ? 'required' : '' ?> autocomplete="new-password">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white fw-bold py-3"><i class="bi bi-shield-lock me-2"></i> Roles & Permissions</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Global System Role</label>
                        <select name="role" class="form-select">
                            <?php $cr = $user['role'] ?? 'subscriber'; ?>
                            <option value="subscriber" <?= $cr === 'subscriber' ? 'selected' : '' ?>>Subscriber (Read Only)</option>
                            <option value="editor" <?= $cr === 'editor' ? 'selected' : '' ?>>Editor (Content Management)</option>
                            <option value="admin" <?= $cr === 'admin' ? 'selected' : '' ?>>Administrator (System Setup)</option>
                            <option value="super_admin" <?= $cr === 'super_admin' ? 'selected' : '' ?>>Super Admin (Full Root Access)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">SEO Override Role</label>
                        <select name="seo_role" class="form-select">
                            <?php $sr = $user['seo_role'] ?? 'none'; ?>
                            <option value="none" <?= $sr === 'none' ? 'selected' : '' ?>>None</option>
                            <option value="seo_manager" <?= $sr === 'seo_manager' ? 'selected' : '' ?>>SEO Manager</option>
                        </select>
                        <div class="form-text small">Allows non-admins to manage redirects, auto-links, and schema data.</div>
                    </div>

                    <hr>

                    <div class="form-check form-switch mt-2">
                        <input class="form-check-input" type="checkbox" name="is_active" id="isActive" value="1" <?= ($user['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label fw-bold" for="isActive">Account is Active</label>
                    </div>
                </div>
                <div class="card-footer bg-light text-end">
                    <button type="submit" class="btn btn-primary w-100 fw-bold">Save User</button>
                </div>
            </div>

            <div class="card border-0 shadow-sm mb-4 text-center py-4">
                <div class="card-body">
                    <img src="https://www.gravatar.com/avatar/<?= md5(strtolower(trim($user['email'] ?? ''))) ?>?s=150&d=mp" class="rounded-circle shadow mb-3" width="120" height="120" alt="Avatar">
                    <p class="small text-muted mb-0">Profile images are synced automatically via Gravatar using the provided email address.</p>
                </div>
            </div>
        </div>
    </div>
</form>

<?php 
$content = ob_get_clean();
require dirname(__DIR__) . '/_layout.php';
?>
