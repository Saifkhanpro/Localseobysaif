<?php
namespace Controllers\Admin;
use Core\Controller;
class ProfileController extends Controller {
    public function __call($name, $arguments) {
        $this->requireAuth();
        echo "<h1>Under Construction</h1><p>Profile module ($name) is being built.</p>";
    }
}
