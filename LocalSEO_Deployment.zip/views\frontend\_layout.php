<?php
use Core\Helpers;
$locale = 'en_PK';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <title><?= Helpers::escape($pageTitle ?? Helpers::setting('site_title', 'LocalSEO.pk')) ?></title>
    
    <?php if (!empty($metaDescription)): ?>
    <meta name="description" content="<?= Helpers::escape($metaDescription) ?>">
    <?php endif; ?>
    
    <?php if (!empty($canonicalUrl)): ?>
    <link rel="canonical" href="<?= Helpers::escape($canonicalUrl) ?>">
    <?php endif; ?>

    <?php if (!empty($robots)): ?>
    <meta name="robots" content="<?= Helpers::escape(implode(', ', $robots)) ?>">
    <?php endif; ?>

    <!-- Schema Markup Injection -->
    <?php if (!empty($schema)): ?>
    <script type="application/ld+json">
        <?= json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
    </script>
    <?php endif; ?>

    <!-- Preloads & Critical Assets -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Outfit:wght@500;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS (Vanilla custom built locally or via CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <!-- Global Custom Styles -->
    <link rel="stylesheet" href="/assets/css/style.css?v=<?= LSEO_VERSION ?>">

    <!-- Embedded Theme Variables -->
    <style>
        :root {
            --primary-color: <?= Helpers::setting('primary_color', '#2563eb') ?>;
            --secondary-color: #1e40af;
            --body-font: <?= Helpers::setting('body_font', "'Inter', sans-serif") ?>;
            --heading-font: <?= Helpers::setting('heading_font', "'Outfit', sans-serif") ?>;
        }
    </style>

    <?php if (Helpers::setting('seo_module_analytics') == '1' && $gaCode = Helpers::setting('ga_code')): ?>
    <!-- Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= $gaCode ?>"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '<?= $gaCode ?>');
    </script>
    <?php endif; ?>

    <?= $extraHead ?? '' ?>
</head>
<body>

    <!-- Header Navigation -->
    <header class="site-header sticky-top bg-white shadow-sm border-bottom">
        <div class="container-fluid px-lg-5">
            <nav class="navbar navbar-expand-lg navbar-light py-3">
                <a class="navbar-brand fw-bold fs-4 d-flex align-items-center" href="/">
                    <?php if (Helpers::setting('logo_url')): ?>
                        <img src="<?= Helpers::escape(Helpers::setting('logo_url')) ?>" alt="<?= Helpers::escape(Helpers::setting('seo_business_name', 'LocalSEO.pk')) ?> Logo" height="40" class="me-2">
                    <?php else: ?>
                        <i class="bi bi-geo-alt-fill text-primary me-2"></i> LocalSEO.pk
                    <?php endif; ?>
                </a>
                
                <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="mainNav">
                    <!-- Placeholder Menu (To be replaced by DB Menu Builder integration) -->
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 fw-medium">
                        <li class="nav-item"><a class="nav-link px-lg-3" href="/">Home</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3" href="/services">SEO Services</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle px-lg-3" href="#" id="cityDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Locations
                            </a>
                            <ul class="dropdown-menu border-0 shadow-sm" aria-labelledby="cityDropdown">
                                <li><a class="dropdown-item" href="/local-seo/lahore">Lahore</a></li>
                                <li><a class="dropdown-item" href="/local-seo/karachi">Karachi</a></li>
                                <li><a class="dropdown-item" href="/local-seo/islamabad">Islamabad</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/local-seo">View All Cities</a></li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="nav-link px-lg-3" href="/case-studies">Case Studies</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3" href="/blog">Blog</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3" href="/about">About Us</a></li>
                    </ul>
                    
                    <div class="d-flex align-items-center ms-lg-4 mt-3 mt-lg-0">
                        <a href="tel:<?= Helpers::escape(Helpers::setting('seo_business_phone', str_replace(' ', '', '+92 300 0000000'))) ?>" class="text-decoration-none fw-bold text-dark me-4 d-none d-xl-block">
                            <i class="bi bi-telephone text-primary me-2"></i> <?= Helpers::escape(Helpers::setting('seo_business_phone', '+92 300 0000000')) ?>
                        </a>
                        <a href="/contact" class="btn btn-primary rounded-pill px-4 py-2 fw-semibold shadow-sm">Get Free Audit</a>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <!-- Main Content Area -->
    <main class="site-main">
        <?php if ($flash = Helpers::flash('success')): ?>
            <div class="container mt-4">
                <div class="alert alert-success alert-dismissible bg-success text-white border-0 shadow-sm fade show" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= Helpers::escape($flash) ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>
        <?php if ($flash = Helpers::flash('error')): ?>
            <div class="container mt-4">
                <div class="alert alert-danger alert-dismissible bg-danger text-white border-0 shadow-sm fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= Helpers::escape($flash) ?>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        <?php endif; ?>

        <!-- Render View -->
        <?= $content ?>
    </main>

    <!-- Site Footer -->
    <footer class="site-footer bg-dark text-white pt-5 pb-3 mt-5">
        <div class="container pt-4">
            <div class="row g-5 mb-5">
                <div class="col-lg-4 col-md-6">
                    <a href="/" class="d-inline-flex align-items-center text-white text-decoration-none mb-4 fs-4 fw-bold">
                        <i class="bi bi-geo-alt-fill text-primary me-2"></i> LocalSEO.pk
                    </a>
                    <p class="text-light opacity-75 mb-4">
                        <?= Helpers::escape(Helpers::setting('site_description', 'The leading local SEO agency in Pakistan helping businesses dominate local search results and drive real revenue.')) ?>
                    </p>
                    <div class="d-flex gap-3">
                        <a href="#" class="text-white opacity-75 text-decoration-none fs-5"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="text-white opacity-75 text-decoration-none fs-5"><i class="bi bi-linkedin"></i></a>
                        <a href="#" class="text-white opacity-75 text-decoration-none fs-5"><i class="bi bi-twitter"></i></a>
                        <a href="#" class="text-white opacity-75 text-decoration-none fs-5"><i class="bi bi-instagram"></i></a>
                    </div>
                </div>
                
                <div class="col-lg-2 col-md-6">
                    <h5 class="text-white mb-4 fw-bold">Company</h5>
                    <ul class="list-unstyled footer-links">
                        <li class="mb-2"><a href="/about" class="text-white opacity-75 text-decoration-none">About Us</a></li>
                        <li class="mb-2"><a href="/services" class="text-white opacity-75 text-decoration-none">SEO Services</a></li>
                        <li class="mb-2"><a href="/case-studies" class="text-white opacity-75 text-decoration-none">Case Studies</a></li>
                        <li class="mb-2"><a href="/blog" class="text-white opacity-75 text-decoration-none">SEO Blog</a></li>
                        <li class="mb-2"><a href="/contact" class="text-white opacity-75 text-decoration-none">Contact Us</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6">
                    <h5 class="text-white mb-4 fw-bold">Top Locations</h5>
                    <ul class="list-unstyled footer-links">
                        <li class="mb-2"><a href="/local-seo/lahore" class="text-white opacity-75 text-decoration-none">SEO Services Lahore</a></li>
                        <li class="mb-2"><a href="/local-seo/karachi" class="text-white opacity-75 text-decoration-none">SEO Services Karachi</a></li>
                        <li class="mb-2"><a href="/local-seo/islamabad" class="text-white opacity-75 text-decoration-none">SEO Services Islamabad</a></li>
                        <li class="mb-2"><a href="/local-seo/faisalabad" class="text-white opacity-75 text-decoration-none">SEO Services Faisalabad</a></li>
                        <li class="mb-2"><a href="/local-seo" class="text-white opacity-75 text-decoration-none">All Cities</a></li>
                    </ul>
                </div>

                <div class="col-lg-3 col-md-6">
                    <h5 class="text-white mb-4 fw-bold">Contact Info</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3 d-flex text-white opacity-75">
                            <i class="bi bi-geo-alt text-primary fs-5 me-3"></i> 
                            <span><?= Helpers::escape(Helpers::setting('seo_business_street', 'Office 123, Tech Plaza')) ?>,<br><?= Helpers::escape(Helpers::setting('seo_business_city', 'Lahore, Pakistan')) ?></span>
                        </li>
                        <li class="mb-3 d-flex text-white opacity-75">
                            <i class="bi bi-telephone text-primary fs-5 me-3"></i> 
                            <span><?= Helpers::escape(Helpers::setting('seo_business_phone', '+92 300 1234567')) ?></span>
                        </li>
                        <li class="mb-3 d-flex text-white opacity-75">
                            <i class="bi bi-envelope text-primary fs-5 me-3"></i> 
                            <span><?= Helpers::escape(Helpers::setting('admin_email', 'info@localseo.pk')) ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <div class="border-top border-secondary pt-4 d-flex flex-column flex-md-row justify-content-between align-items-center">
                <p class="mb-0 text-white opacity-50 small">&copy; <?= date('Y') ?> <?= Helpers::escape(Helpers::setting('seo_business_name', 'LocalSEO.pk')) ?>. All Rights Reserved.</p>
                <div class="mt-3 mt-md-0">
                    <a href="/privacy-policy" class="text-white opacity-50 text-decoration-none small me-3">Privacy Policy</a>
                    <a href="/terms-of-service" class="text-white opacity-50 text-decoration-none small">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- WhatsApp Floating Button -->
    <a href="https://wa.me/<?= str_replace(['+', ' ', '-'], '', Helpers::setting('seo_business_phone', '923000000000')) ?>?text=Hi%2C%20I%20want%20to%20grow%20my%20local%20business%20with%20SEO." target="_blank" class="whatsapp-float bg-success text-white shadow" title="Chat on WhatsApp">
        <i class="bi bi-whatsapp"></i>
    </a>

    <style>
        .site-header { z-index: 1040; transition: all 0.3s ease; }
        .nav-link { color: #333 !important; font-weight: 500; }
        .nav-link:hover { color: var(--primary-color) !important; }
        .footer-links a:hover { color: var(--primary-color) !important; opacity: 1 !important; padding-left: 5px; transition: all 0.2s; }
        .whatsapp-float { position: fixed; width: 60px; height: 60px; bottom: 40px; right: 40px; border-radius: 50px; text-align: center; font-size: 30px; box-shadow: 2px 2px 3px #999; z-index: 100; display: flex; align-items: center; justify-content: center; text-decoration: none; transition: transform 0.3s; }
        .whatsapp-float:hover { transform: scale(1.1); color: white; }
        body { font-family: var(--body-font); color: #334155; }
        h1, h2, h3, h4, h5, h6 { font-family: var(--heading-font); color: #0f172a; }
        .text-primary { color: var(--primary-color) !important; }
        .bg-primary { background-color: var(--primary-color) !important; }
        .btn-primary { background-color: var(--primary-color); border-color: var(--primary-color); }
        .btn-primary:hover { background-color: var(--secondary-color); border-color: var(--secondary-color); }
    </style>

    <!-- Core Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.css"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="/assets/js/main.js?v=<?= LSEO_VERSION ?>"></script>

    <?= $extraFooter ?? '' ?>
</body>
</html>
