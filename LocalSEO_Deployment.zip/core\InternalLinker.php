<?php
namespace Core;

class InternalLinker {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function processAutoLinks(string $content, int $postId, string $type = 'post'): string {
        $settings = $GLOBALS['settings'] ?? [];
        if (($settings['seo_auto_links_enabled'] ?? '0') !== '1') return $content;

        $t = $this->db->t('seo_auto_links');
        $rules = $this->db->fetchAll("SELECT * FROM {$t} WHERE is_active = 1 ORDER BY priority DESC, LENGTH(keyword) DESC");
        
        if (empty($rules)) return $content;

        $maxTotal = (int)($settings['seo_auto_links_max_per_post'] ?? 3);
        $totalLinksAdded = 0;
        
        $newTab = ($settings['seo_auto_links_new_tab'] ?? '0') === '1' ? ' target="_blank"' : '';
        $nofollow = ($settings['seo_auto_links_nofollow'] ?? '0') === '1' ? ' rel="nofollow"' : '';
        $attr = $newTab . $nofollow;

        $excludeHeadings = ($settings['seo_auto_links_exclude_headings'] ?? '1') === '1';

        // Extract HTML tags to avoid replacing text inside attributes or existing links
        $parts = preg_split('/(<[^>]+>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE);
        
        $inHeading = false;
        $inLink = false;

        foreach ($parts as &$part) {
            if ($totalLinksAdded >= $maxTotal) break;
            
            // Check if it's an HTML tag
            if (strpos($part, '<') === 0) {
                $tagType = strtolower(substr($part, 1, 3));
                if (strpos($tagType, 'a') === 0 || strpos($tagType, 'a ') === 0) $inLink = true;
                if (strpos($tagType, '/a>') === 0) $inLink = false;
                
                if ($excludeHeadings) {
                    if (preg_match('/^<h[1-6]/i', $tagType)) $inHeading = true;
                    if (preg_match('/^<\/h[1-6]/i', $tagType)) $inHeading = false;
                }
                continue;
            }

            if ($inLink || $inHeading) continue;

            // Process text part for auto-links
            foreach ($rules as $rule) {
                if ($totalLinksAdded >= $maxTotal) break;
                
                // Exclude specific posts
                if (!empty($rule['exclude_posts'])) {
                    $excludes = array_map('trim', explode(',', $rule['exclude_posts']));
                    if (in_array($postId, $excludes)) continue;
                }

                $maxPerRule = (int)($rule['max_links_per_post'] ?? 1);
                $ruleHits = 0;

                $keyword = preg_quote($rule['keyword'], '/');
                $target = $rule['target_url'];
                
                // Match exact word boundaries, case-insensitive
                $part = preg_replace_callback("/\b({$keyword})\b/i", function($m) use (&$totalLinksAdded, &$ruleHits, $maxPerRule, $target, $attr) {
                    if ($ruleHits < $maxPerRule) {
                        $ruleHits++;
                        $totalLinksAdded++;
                        return "<a href=\"{$target}\"{$attr} class=\"auto-link\">{$m[1]}</a>";
                    }
                    return $m[1];
                }, $part, max(1, $maxPerRule));

                if ($ruleHits > 0) {
                    $this->db->query("UPDATE {$t} SET current_count = current_count + ? WHERE id = ?", [$ruleHits, $rule['id']]);
                }
            }
        }

        return implode('', $parts);
    }

    public function suggestLinks(string $content, int $excludeId = 0): array {
        $prefix = $this->db->getTablePrefix();
        $words = array_unique(str_word_count(strtolower(strip_tags($content)), 1));
        $importantWords = array_filter($words, function($w) {
            return mb_strlen($w) > 4 && !in_array($w, ['there','their','where','which','would','could','should','about','these']);
        });

        if (empty($importantWords)) return [];

        $placeholders = implode(',', array_fill(0, count($importantWords), '?'));
        $sql = "SELECT id, title, slug, focus_keyword FROM {$prefix}posts 
                WHERE status = 'published' AND id != ? 
                AND focus_keyword IN ({$placeholders}) LIMIT 5";
        
        $params = array_merge([$excludeId], $importantWords);
        return $this->db->fetchAll($sql, $params);
    }
}
