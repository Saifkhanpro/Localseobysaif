<?php ob_start(); ?>

<div class="bg-light py-5 border-bottom">
    <div class="container py-4 text-center">
        <h1 class="display-4 fw-bolder mb-3 text-dark">Local SEO Services</h1>
        <p class="lead text-muted max-w-700 mx-auto">Comprehensive local search engine optimization services tailored for businesses in Pakistan. Dominate local maps and drive real foot traffic.</p>
    </div>
</div>

<div class="container py-5 my-4">
    <div class="row g-4 g-lg-5">
        <?php foreach ($services as $service): ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100 border-0 shadow-sm rounded-4 service-card transition-all">
                <?php if ($service['featured_image_id']): ?>
                    <?php 
                        $db = \Core\Database::getInstance();
                        $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$service['featured_image_id']]);
                        $imgSrc = $media ? '/' . ltrim($media['file_path'], '/') : 'https://placehold.co/600x400/f8f9fa/adb5bd?text=Service';
                    ?>
                    <img src="<?= $imgSrc ?>" class="card-img-top rounded-top-4" alt="<?= \Core\Helpers::escape($service['title']) ?>" style="height: 200px; object-fit: cover;">
                <?php else: ?>
                    <div class="card-img-top bg-light rounded-top-4 d-flex align-items-center justify-content-center border-bottom" style="height: 200px;">
                        <i class="<?= \Core\Helpers::escape($service['icon_class'] ?: 'bi bi-graph-up-arrow') ?> text-primary opacity-50" style="font-size: 5rem;"></i>
                    </div>
                <?php endif; ?>
                
                <div class="card-body p-4 p-lg-5 d-flex flex-column">
                    <h3 class="h4 fw-bold mb-3"><a href="/services/<?= \Core\Helpers::escape($service['slug']) ?>" class="text-dark text-decoration-none stretched-link"><?= \Core\Helpers::escape($service['title']) ?></a></h3>
                    <p class="text-muted mb-4 flex-grow-1"><?= \Core\Helpers::escape($service['short_description']) ?></p>
                    
                    <div class="mt-auto d-flex justify-content-between align-items-center border-top pt-3">
                        <?php if ($service['price_range']): ?>
                        <span class="text-dark fw-bold bg-light px-3 py-1 rounded fs-6"><?= \Core\Helpers::escape($service['price_range']) ?></span>
                        <?php endif; ?>
                        <span class="fw-semibold text-primary d-inline-flex align-items-center">
                            Details <i class="bi bi-arrow-right ms-2 transition-transform"></i>
                        </span>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
    .max-w-700 { max-width: 700px; }
    .transition-all { transition: all 0.3s ease; }
    .service-card:hover { transform: translateY(-10px); box-shadow: 0 1.5rem 4rem rgba(0,0,0,.08)!important; }
    .service-card .bi-arrow-right { transition: transform 0.2s; }
    .service-card:hover .bi-arrow-right { transform: translateX(5px); }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
