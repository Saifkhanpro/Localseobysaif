<?php
namespace Models;
use Core\Model;

class LoginAttempt extends Model {
    protected $table = 'login_attempts';
    protected $fillable = ['ip_address', 'username', 'success', 'user_agent'];
}
