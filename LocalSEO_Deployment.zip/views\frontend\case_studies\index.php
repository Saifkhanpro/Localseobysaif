<?php ob_start(); ?>

<div class="bg-dark py-5 text-white border-bottom">
    <div class="container py-4 text-center">
        <h1 class="display-4 fw-bolder mb-3 text-white">Local SEO Case Studies & Results</h1>
        <p class="lead text-white-50 max-w-700 mx-auto">See how we've helped Pakistani businesses dominate their local search markets, increase organic traffic, and significantly boost their revenue.</p>
    </div>
</div>

<div class="container py-5 my-4">
    <div class="row g-4 g-lg-5">
        <?php foreach ($cases as $case): ?>
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100 border-0 shadow-sm rounded-4 case-card transition-all overflow-hidden flex-column">
                <?php if ($case['featured_image_id']): ?>
                    <?php 
                        $db = \Core\Database::getInstance();
                        $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id = ?", [$case['featured_image_id']]);
                        $imgSrc = $media ? '/' . ltrim($media['file_path'], '/') : 'https://placehold.co/600x400/1e293b/ffffff?text=Case+Study';
                    ?>
                    <img src="<?= $imgSrc ?>" class="card-img-top" alt="<?= \Core\Helpers::escape($case['title']) ?>" style="height: 220px; object-fit: cover;">
                <?php else: ?>
                    <div class="card-img-top bg-secondary d-flex align-items-center justify-content-center" style="height: 220px;">
                        <i class="bi bi-graph-up-arrow text-white-50" style="font-size: 5rem;"></i>
                    </div>
                <?php endif; ?>
                
                <div class="card-body p-4 p-lg-5 d-flex flex-column h-100">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-2 fw-semibold tracking-wide text-uppercase" style="font-size: 0.75rem;"><?= \Core\Helpers::escape($case['industry']) ?></span>
                    </div>
                    
                    <h3 class="h4 fw-bold mb-3"><a href="/case-studies/<?= \Core\Helpers::escape($case['slug']) ?>" class="text-dark text-decoration-none stretched-link case-title"><?= \Core\Helpers::escape($case['title']) ?></a></h3>
                    <p class="text-muted mb-4 flex-grow-1"><?= \Core\Helpers::escape(mb_strimwidth(strip_tags($case['challenge']), 0, 120, '...')) ?></p>
                    
                    <div class="mt-auto border-top pt-4">
                        <div class="row text-center g-2 w-100 mb-3">
                            <div class="col-6 border-end">
                                <span class="d-block text-muted small text-uppercase tracking-wide fw-semibold mb-1" style="font-size: 0.7rem;">Client</span>
                                <span class="fw-bold text-dark fs-6"><?= \Core\Helpers::escape(mb_strimwidth($case['client_name'], 0, 15, '..')) ?></span>
                            </div>
                            <div class="col-6">
                                <span class="d-block text-muted small text-uppercase tracking-wide fw-semibold mb-1" style="font-size: 0.7rem;">Results</span>
                                <span class="fw-bold text-success fs-6"><i class="bi bi-arrow-up text-success"></i> 10x ROI</span>
                            </div>
                        </div>
                        <div class="text-center w-100 mt-2">
                             <span class="fw-bold text-primary d-inline-flex align-items-center text-uppercase tracking-wide" style="font-size: 0.8rem;">
                                Read Case Study <i class="bi bi-arrow-right ms-2 transition-transform"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
    .max-w-700 { max-width: 700px; }
    .tracking-wide { letter-spacing: 0.05em; }
    .transition-all { transition: all 0.3s ease; }
    .case-card:hover { transform: translateY(-10px); box-shadow: 0 1.5rem 4rem rgba(0,0,0,.12)!important; }
    .case-card img { transition: transform 0.5s ease; }
    .case-card:hover img { transform: scale(1.03); }
    .case-title { transition: color 0.2s ease; }
    .case-card:hover .case-title { color: var(--primary-color)!important; }
    .case-card .bi-arrow-right { transition: transform 0.2s; }
    .case-card:hover .bi-arrow-right { transform: translateX(5px); }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
