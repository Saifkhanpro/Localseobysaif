<?php
namespace Controllers\Frontend;
use Core\Controller;
class SearchController extends Controller {
    public function index() {
        echo "<h1>Search Results</h1><p>Search feature (stub).</p>";
    }
}
