<?php
namespace Models;
use Core\Model;

class Lead extends Model {
    protected $table = 'leads';
    protected $fillable = [
        'full_name', 'email', 'phone', 'whatsapp_number', 'city', 'service_needed',
        'message', 'status', 'ip_address', 'user_agent', 'source_url', 'utm_source',
        'utm_medium', 'utm_campaign', 'notes', 'assigned_to', 'is_read'
    ];

    public function markRead(int $id): bool {
        return $this->update($id, ['is_read' => 1]) > 0;
    }

    public function getUnreadCount(): int {
        return $this->count("is_read = 0");
    }
}
