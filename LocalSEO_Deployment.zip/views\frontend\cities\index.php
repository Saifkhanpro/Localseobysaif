<?php ob_start(); ?>

<div class="bg-primary py-5 text-white border-bottom">
    <div class="container py-4 text-center">
        <h1 class="display-4 fw-bolder mb-3 text-white">Local SEO Services Near You</h1>
        <p class="lead text-white-50 max-w-700 mx-auto">Find expert local search optimization services in your specific city across Pakistan. We help local businesses dominate their exact geographic market.</p>
    </div>
</div>

<div class="container py-5 my-4">
    <!-- Featured Cities / Major Hubs Grids -->
    <div class="row g-4 mb-5 pb-4 border-bottom">
        <div class="col-12 mb-2">
            <h2 class="h3 fw-bold">Top SEO Locations</h2>
        </div>
        
        <?php foreach ($cities as $city): ?>
            <div class="col-md-4 col-sm-6 mb-4">
                <a href="/local-seo/<?= \Core\Helpers::escape($city['slug']) ?>" class="card text-decoration-none shadow-sm h-100 border-0 overflow-hidden city-card">
                    <?php if ($city['featured_image_id']): ?>
                        <?php 
                            $db = \Core\Database::getInstance();
                            $media = $db->fetch("SELECT file_path FROM {$db->t('media')} WHERE id =?", [$city['featured_image_id']]);
                            $imgSrc = $media ? '/' . ltrim($media['file_path'], '/') : 'https://placehold.co/600x400/2563eb/ffffff?text=' . urlencode($city['city_name']);
                        ?>
                        <img src="<?= $imgSrc ?>" class="card-img-top" alt="Local SEO in <?= \Core\Helpers::escape($city['city_name']) ?>" style="height: 180px; object-fit: cover;">
                    <?php else: ?>
                        <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 180px;">
                            <i class="bi bi-geo-alt-fill text-primary" style="font-size: 3rem;"></i>
                        </div>
                    <?php endif; ?>
                    <div class="card-img-overlay d-flex align-items-end p-0 bg-gradient-dark rounded-0">
                        <div class="p-4 w-100 text-white">
                            <h3 class="h4 fw-bold mb-1 text-white"><?= \Core\Helpers::escape($city['city_name']) ?></h3>
                            <?php if ($city['state_province']): ?>
                            <p class="mb-0 fs-6 opacity-75"><i class="bi bi-pin-map-fill me-1"></i><?= \Core\Helpers::escape($city['state_province']) ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- CTA for locations not listed -->
    <div class="bg-light rounded-4 p-5 text-center mt-5 d-flex flex-column align-items-center border border-2 border-primary-subtle">
        <i class="bi bi-search text-primary fs-1 mb-3"></i>
        <h3 class="fw-bold mb-2 h2">Don't see your city?</h3>
        <p class="text-muted lead max-w-700 mx-auto mb-4">We serve clients nationwide. If you're a local business in Pakistan looking to rank higher on Google Maps, get in touch with us today.</p>
        <a href="/contact" class="btn btn-primary btn-lg rounded-pill px-5 fw-bold shadow">Contact Us Today</a>
    </div>
</div>

<style>
    .max-w-700 { max-width: 700px; }
    .bg-gradient-dark { background: linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 40%, transparent 100%); }
    .city-card { transition: transform 0.3s ease, box-shadow 0.3s ease; }
    .city-card:hover { transform: translateY(-7px); box-shadow: 0 1rem 3rem rgba(0,0,0,.15)!important; }
    .city-card img { transition: transform 0.5s ease; }
    .city-card:hover img { transform: scale(1.05); }
</style>

<?php
$content = ob_get_clean();
require VIEW_PATH . '/frontend/_layout.php';
?>
