<?php
namespace Core;

class Mailer {
    public static function send(string $to, string $subject, string $body, array $headers = []): bool {
        $fromEmail = defined('MAIL_FROM_EMAIL') ? MAIL_FROM_EMAIL : 'noreply@localseo.pk';
        $fromName = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : 'LocalSEO.pk';

        $defaultHeaders = [
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            "From: {$fromName} <{$fromEmail}>",
            "Reply-To: {$fromEmail}",
            'X-Mailer: LocalSEO-CMS/1.0',
        ];
        $allHeaders = array_merge($defaultHeaders, $headers);
        $htmlBody = self::wrapInTemplate($subject, $body);
        return @mail($to, $subject, $htmlBody, implode("\r\n", $allHeaders));
    }

    public static function sendContactNotification(array $contact): bool {
        $notifyEmail = Helpers::setting('contact_notification_email', Helpers::setting('admin_email', 'info@localseo.pk'));
        $subject = 'New Lead: ' . htmlspecialchars($contact['full_name']) . ' — ' . Helpers::setting('site_title', 'LocalSEO.pk');
        $body = '<h2>New Contact Form Submission</h2>';
        $body .= '<table style="width:100%;border-collapse:collapse;">';
        $fields = ['Name' => 'full_name', 'Email' => 'email', 'Phone' => 'phone', 'WhatsApp' => 'whatsapp_number', 'City' => 'city', 'Service' => 'service_needed'];
        foreach ($fields as $label => $key) {
            if (!empty($contact[$key])) {
                $body .= '<tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;width:120px;">' . $label . '</td>';
                $body .= '<td style="padding:8px;border:1px solid #ddd;">' . htmlspecialchars($contact[$key]) . '</td></tr>';
            }
        }
        $body .= '<tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;vertical-align:top;">Message</td>';
        $body .= '<td style="padding:8px;border:1px solid #ddd;">' . nl2br(htmlspecialchars($contact['message'])) . '</td></tr>';
        $body .= '</table>';
        $body .= '<p style="margin-top:20px;"><a href="' . Helpers::adminUrl('leads') . '" style="background:#2563eb;color:#fff;padding:10px 20px;text-decoration:none;border-radius:6px;">View in Dashboard</a></p>';
        return self::send($notifyEmail, $subject, $body);
    }

    public static function sendPasswordReset(string $email, string $resetUrl): bool {
        $subject = 'Password Reset — ' . Helpers::setting('site_title', 'LocalSEO.pk');
        $body = '<h2>Password Reset Request</h2>';
        $body .= '<p>Click the link below to reset your password. This link expires in 1 hour.</p>';
        $body .= '<p><a href="' . $resetUrl . '" style="background:#2563eb;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;display:inline-block;">Reset Password</a></p>';
        $body .= '<p style="color:#666;font-size:13px;">If you didn\'t request this, please ignore this email.</p>';
        return self::send($email, $subject, $body);
    }

    public static function sendUpdateNotification(string $version, string $type): bool {
        $adminEmail = Helpers::setting('admin_email', 'info@localseo.pk');
        $subject = ($type === 'security' ? '🔒 Security' : '🔄') . " Update Available: v{$version} — " . Helpers::setting('site_title');
        $body = "<h2>System Update Available</h2><p>Version <strong>{$version}</strong> ({$type}) is available.</p>";
        $body .= '<p><a href="' . Helpers::adminUrl('updates') . '" style="background:#2563eb;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;">Update Now</a></p>';
        return self::send($adminEmail, $subject, $body);
    }

    private static function wrapInTemplate(string $subject, string $body): string {
        $siteName = Helpers::setting('site_title', 'LocalSEO.pk');
        return '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($subject) . '</title></head>'
            . '<body style="margin:0;padding:0;background:#f4f4f5;font-family:Arial,sans-serif;">'
            . '<div style="max-width:600px;margin:40px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.07);">'
            . '<div style="background:linear-gradient(135deg,#1e40af,#3b82f6);padding:24px 32px;color:#fff;"><h1 style="margin:0;font-size:20px;">' . htmlspecialchars($siteName) . '</h1></div>'
            . '<div style="padding:32px;">' . $body . '</div>'
            . '<div style="padding:16px 32px;background:#f9fafb;text-align:center;color:#9ca3af;font-size:12px;">© ' . date('Y') . ' ' . htmlspecialchars($siteName) . '</div>'
            . '</div></body></html>';
    }
}
