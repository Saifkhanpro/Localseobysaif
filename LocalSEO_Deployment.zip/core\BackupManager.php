<?php
namespace Core;

class BackupManager {
    public function createFullBackup(): array {
        $filename = 'backup-' . date('Y-m-d-His') . '.zip';
        $filepath = BACKUP_PATH . '/' . $filename;
        
        $zip = new \ZipArchive();
        if ($zip->open($filepath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
            return ['success' => false, 'error' => 'Cannot create zip file in backups directory.'];
        }

        // Add files
        $this->addFolderToZip(ROOT_PATH, $zip, ['/cache', '/backups', '/temp', '/uploads']);
        
        // Add DB dump
        $sqlFile = BACKUP_PATH . '/db-dump.sql';
        if ($this->exportDatabase($sqlFile)) {
            $zip->addFile($sqlFile, 'database.sql');
        }

        $zip->close();
        @unlink($sqlFile);

        // Cleanup old backups based on retention policy
        $this->cleanupOldBackups();

        return ['success' => true, 'file' => $filename, 'size' => filesize($filepath)];
    }

    private function addFolderToZip($dir, $zip, $exclusions, $base = '') {
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file == '.' || $file == '..') continue;
            
            $path = $dir . '/' . $file;
            $localPath = $base ? $base . '/' . $file : $file;
            
            // Skip exclusions (quick check against leading paths)
            $skip = false;
            foreach ($exclusions as $ex) {
                if (strpos('/' . $localPath, $ex) === 0) {
                    $skip = true;
                    break;
                }
            }
            if ($skip) continue;

            if (is_dir($path)) {
                $zip->addEmptyDir($localPath);
                $this->addFolderToZip($path, $zip, $exclusions, $localPath);
            } else {
                $zip->addFile($path, $localPath);
            }
        }
    }

    private function exportDatabase(string $filepath): bool {
        // Simplified raw SQL dump mechanism
        $db = Database::getInstance();
        $fp = fopen($filepath, 'w');
        if (!$fp) return false;

        fwrite($fp, "-- Database Dump\n-- Generated: " . date('Y-m-d H:i:s') . "\n\n");
        fwrite($fp, "SET FOREIGN_KEY_CHECKS=0;\n\n");

        $tables = $db->fetchAll("SHOW TABLES");
        foreach ($tables as $tRow) {
            $table = array_values($tRow)[0];
            $create = $db->fetch("SHOW CREATE TABLE `{$table}`");
            fwrite($fp, "DROP TABLE IF EXISTS `{$table}`;\n");
            fwrite($fp, $create['Create Table'] . ";\n\n");

            $rows = $db->fetchAll("SELECT * FROM `{$table}`");
            foreach ($rows as $row) {
                $vals = array_map(function($v) use ($db) {
                    if ($v === null) return 'NULL';
                    return $db->getPdo()->quote($v);
                }, $row);
                fwrite($fp, "INSERT INTO `{$table}` VALUES (" . implode(',', $vals) . ");\n");
            }
            fwrite($fp, "\n");
        }

        fwrite($fp, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($fp);
        return true;
    }

    private function cleanupOldBackups(): void {
        $retention = (int)($GLOBALS['settings']['update_backup_retention'] ?? 5);
        if ($retention <= 0) return;

        $files = glob(BACKUP_PATH . '/backup-*.zip');
        if (count($files) > $retention) {
            usort($files, fn($a, $b) => filemtime($b) - filemtime($a));
            $toDelete = array_slice($files, $retention);
            foreach ($toDelete as $f) {
                @unlink($f);
            }
        }
    }
}
