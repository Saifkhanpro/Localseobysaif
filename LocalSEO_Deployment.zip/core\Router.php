<?php
namespace Core;

class Router {
    private $routes = ['GET' => [], 'POST' => []];
    private $notFoundCallback = null;

    public function get(string $path, string $action): void {
        $this->routes['GET'][$path] = $action;
    }

    public function post(string $path, string $action): void {
        $this->routes['POST'][$path] = $action;
    }

    public function dispatch(): void {
        $method = $_SERVER['REQUEST_METHOD'];
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri = rtrim($uri, '/') ?: '/';

        // Check redirects from database
        $this->checkRedirects($uri);

        // Check for 404 logging
        $matched = false;

        if (isset($this->routes[$method])) {
            foreach ($this->routes[$method] as $route => $action) {
                $pattern = $this->routeToRegex($route);
                if (preg_match($pattern, $uri, $matches)) {
                    $matched = true;
                    $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                    $this->callAction($action, $params);
                    return;
                }
            }
        }

        if (!$matched) {
            $this->log404($uri);
            http_response_code(404);
            $this->callAction('frontend/PageController@error404', []);
        }
    }

    private function routeToRegex(string $route): string {
        $pattern = preg_replace('/\{([a-zA-Z_]+)\}/', '(?P<$1>[^/]+)', $route);
        return '#^' . $pattern . '$#';
    }

    private function callAction(string $action, array $params): void {
        list($controllerPath, $method) = explode('@', $action);
        $parts = explode('/', $controllerPath);
        $controllerFile = CONTROLLER_PATH . '/' . $controllerPath . '.php';

        if (!file_exists($controllerFile)) {
            http_response_code(500);
            if (defined('APP_DEBUG') && APP_DEBUG) {
                die("Controller file not found: {$controllerFile}");
            }
            die('Internal server error.');
        }

        require_once $controllerFile;

        $className = 'Controllers\\' . str_replace('/', '\\', $controllerPath);
        if (!class_exists($className)) {
            http_response_code(500);
            if (defined('APP_DEBUG') && APP_DEBUG) {
                die("Controller class not found: {$className}");
            }
            die('Internal server error.');
        }

        $controller = new $className();
        if (!method_exists($controller, $method)) {
            http_response_code(500);
            if (defined('APP_DEBUG') && APP_DEBUG) {
                die("Method not found: {$className}@{$method}");
            }
            die('Internal server error.');
        }

        call_user_func_array([$controller, $method], $params);
    }

    private function checkRedirects(string $uri): void {
        try {
            $db = Database::getInstance();
            $prefix = $db->getTablePrefix();
            $redirect = $db->fetch(
                "SELECT * FROM {$prefix}redirects WHERE source_url = ? AND is_active = 1 LIMIT 1",
                [$uri]
            );
            if ($redirect) {
                $db->query(
                    "UPDATE {$prefix}redirects SET hits = hits + 1, last_hit = NOW() WHERE id = ?",
                    [$redirect['id']]
                );
                $code = (int) $redirect['redirect_type'];
                if ($code === 410) {
                    http_response_code(410);
                    echo '<!DOCTYPE html><html><head><title>410 Gone</title></head><body><h1>410 — Gone</h1><p>This content has been permanently removed.</p></body></html>';
                    exit;
                }
                header('Location: ' . $redirect['target_url'], true, $code);
                exit;
            }
        } catch (\Exception $e) {
            // Silently fail - redirects table may not exist yet
        }
    }

    private function log404(string $uri): void {
        try {
            $db = Database::getInstance();
            $prefix = $db->getTablePrefix();
            $settings = $GLOBALS['settings'] ?? [];
            if (empty($settings['seo_404_log_enabled']) || $settings['seo_404_log_enabled'] !== '1') {
                return;
            }
            $existing = $db->fetch(
                "SELECT id FROM {$prefix}seo_404_log WHERE url = ? AND is_resolved = 0 LIMIT 1",
                [$uri]
            );
            if ($existing) {
                $db->query(
                    "UPDATE {$prefix}seo_404_log SET hits = hits + 1, last_detected = NOW() WHERE id = ?",
                    [$existing['id']]
                );
            } else {
                $db->insert($prefix . 'seo_404_log', [
                    'url' => $uri,
                    'referrer' => $_SERVER['HTTP_REFERER'] ?? null,
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                ]);
            }
        } catch (\Exception $e) {
            // Silently fail
        }
    }
}
