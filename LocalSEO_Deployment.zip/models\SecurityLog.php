<?php
namespace Models;
use Core\Model;

class SecurityLog extends Model {
    protected $table = 'security_log';
    protected $fillable = [
        'event_type', 'user_id', 'username', 'ip_address', 'user_agent',
        'request_uri', 'request_method', 'additional_data', 'severity'
    ];
}
